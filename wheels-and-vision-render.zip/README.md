# Wheels & Vision for All — Free hosting with Render.com

This folder is a ready-to-run version of your website. You do **not** need to
be a developer to put it online. Just follow the steps below. It is **free**.

---

## Why Render.com?

- **Free** plan for small websites like this one.
- **No credit card** required to start.
- **Beginner friendly** — clicks and copy/paste, no commands on your computer.
- Runs the full website (login, bookings, AI assistant) — not just a static page.

> Note: On the free plan the site "sleeps" after ~15 minutes with no visitors
> and takes ~30 seconds to wake up on the next visit. That is normal and fine
> for most charities. You can upgrade later to keep it always-on.

---

## What you will need (5 minutes to gather)

1. A **GitHub** account (free) — https://github.com/signup
2. A **Render** account (free) — https://render.com (click "Get Started", sign in with GitHub)
3. The four secret values for the **Environment variables** (see the bottom of
   this guide). They are also listed in `.env.example`.

---

## Step-by-step

### Part A — Put the files on GitHub (one time)

GitHub is just an online folder. We upload this project there so Render can read it.

1. Go to https://github.com/new
2. **Repository name:** `wheels-and-vision`
3. Choose **Public**, then click **Create repository**.
4. On the next page click the link **"uploading an existing file"**.
5. **Unzip** this download on your computer, then **drag ALL the files and
   folders** (README.md, package.json, the `server` folder, the `public`
   folder, render.yaml, etc.) into the upload box.
6. Click **Commit changes**. Wait for the upload to finish.

### Part B — Create the site on Render

1. Go to https://dashboard.render.com
2. Click **New +** (top right) → **Blueprint**.
3. Connect your GitHub and pick the **wheels-and-vision** repository.
4. Render reads `render.yaml` automatically and shows a service called
   **wheels-and-vision**. Click **Apply**.

   *(If you prefer not to use Blueprint: click New + → **Web Service**, pick the
   repo, set **Build Command** to `npm install`, **Start Command** to
   `npm start`, and **Instance Type** to **Free**.)*

### Part C — Add the secret values

1. Open your new service → **Environment** tab → **Add Environment Variable**.
2. Add these four (names exactly as shown), pasting the values from the bottom
   of this guide:
   - `SUPABASE_URL`
   - `SUPABASE_PUBLISHABLE_KEY`
   - `SUPABASE_SERVICE_ROLE_KEY`
   - `LOVABLE_API_KEY`
3. Click **Save Changes**. Render will rebuild and start the site.

   *(You do NOT need to set `PORT` — Render does that for you.)*

### Part D — Visit your live site

- When the status shows **Live**, click the URL at the top of the page
  (it looks like `https://wheels-and-vision.onrender.com`).
- That's it — your site is online for free. 🎉

---

## Connecting your own domain (optional)

Render → your service → **Settings** → **Custom Domains** → **Add**, then
follow the instructions to point your domain to Render. Free on all plans.

---

## The four Environment variable values

Copy these into Render in **Part C**. (The first two are safe to share; keep the
last two private.)

```
SUPABASE_URL=https://mxumkgshmvbwudvlmsom.supabase.co
SUPABASE_PUBLISHABLE_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im14dW1rZ3NobXZid3Vkdmxtc29tIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODEwMzY0OTUsImV4cCI6MjA5NjYxMjQ5NX0.G8Hh-mOtvRzISOJpRufivAC-9Az-f28PfO-sQnkhQLw
SUPABASE_SERVICE_ROLE_KEY=  (get from your Lovable project — Cloud secrets)
LOVABLE_API_KEY=            (get from your Lovable project — Cloud secrets)
```

> Your **database, login, storage and AI** all keep running on Lovable Cloud.
> Render only hosts the website itself, so keep your Lovable project published.

---

## Other free options (if you ever want to switch)

- **Railway.app** — also easy; small monthly free credit.
- **Koyeb.com** — free web service, similar steps.
- **Keep it on Lovable** — your site is already free at your Lovable URL; you can
  just connect a custom domain there with zero setup.
