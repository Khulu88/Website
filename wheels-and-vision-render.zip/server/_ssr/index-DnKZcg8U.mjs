import { r as reactExports, j as jsxRuntimeExports } from "../_libs/react.mjs";
import { L as Link } from "../_libs/tanstack__react-router.mjs";
import { b as useI18n, B as Button } from "./router-Cq4mEwYw.mjs";
import { l as logoImg, L as LanguageSwitcher } from "./logo-CMkK24B0.mjs";
import "../_libs/sonner.mjs";
import { X, K as Menu, O as ArrowRight, E as Eye, A as Accessibility, Q as Glasses, d as Stethoscope, W as HandHeart, o as CalendarCheck, B as BookOpen, D as Bot, w as Users, t as Heart, L as Lightbulb, l as MapPin, Y as Mail } from "../_libs/lucide-react.mjs";
import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval.mjs";
import "../_libs/seroval-plugins.mjs";
import "node:stream/web";
import "node:stream";
import "../_libs/react-dom.mjs";
import "util";
import "crypto";
import "async_hooks";
import "stream";
import "../_libs/isbot.mjs";
import "../_libs/tanstack__query-core.mjs";
import "../_libs/tanstack__react-query.mjs";
import "./client-Dt-bKJUW.mjs";
import "../_libs/supabase__supabase-js.mjs";
import "../_libs/supabase__postgrest-js.mjs";
import "../_libs/supabase__realtime-js.mjs";
import "../_libs/supabase__phoenix.mjs";
import "../_libs/supabase__storage-js.mjs";
import "../_libs/iceberg-js.mjs";
import "../_libs/supabase__auth-js.mjs";
import "tslib";
import "../_libs/supabase__functions-js.mjs";
import "../_libs/radix-ui__react-slot.mjs";
import "../_libs/radix-ui__react-compose-refs.mjs";
import "../_libs/class-variance-authority.mjs";
import "../_libs/clsx.mjs";
import "../_libs/tailwind-merge.mjs";
import "../_libs/radix-ui__react-switch.mjs";
import "../_libs/radix-ui__primitive.mjs";
import "../_libs/radix-ui__react-context.mjs";
import "../_libs/@radix-ui/react-use-controllable-state+[...].mjs";
import "../_libs/@radix-ui/react-use-layout-effect+[...].mjs";
import "../_libs/radix-ui__react-use-previous.mjs";
import "../_libs/radix-ui__react-use-size.mjs";
import "../_libs/radix-ui__react-primitive.mjs";
function Reveal({
  children,
  className = "",
  delay = 0,
  as: Tag = "div"
}) {
  const ref = reactExports.useRef(null);
  const [visible, setVisible] = reactExports.useState(false);
  reactExports.useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.15, rootMargin: "0px 0px -10% 0px" }
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, []);
  return /* @__PURE__ */ jsxRuntimeExports.jsx(
    Tag,
    {
      ref,
      className: `reveal ${visible ? "is-visible" : ""} ${className}`,
      style: { animationDelay: `${delay}ms` },
      children
    }
  );
}
const heroImg = "/assets/hero-DgLfjf5t.jpg";
const visionImg = "/assets/vision-Dl5uGTmN.jpg";
const mobilityImg = "/assets/mobility-D9MXPQpv.jpg";
const nav = [{
  label: "nav.about",
  href: "#about"
}, {
  label: "nav.programmes",
  href: "#programmes"
}, {
  label: "nav.impact",
  href: "#impact"
}, {
  label: "nav.involved",
  href: "#involved"
}, {
  label: "nav.contact",
  href: "#contact"
}];
function Index() {
  const [open, setOpen] = reactExports.useState(false);
  const {
    t
  } = useI18n();
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-h-screen bg-background text-foreground", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("header", { className: "fixed inset-x-0 top-0 z-50 border-b border-border/60 bg-background/85 backdrop-blur-md", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mx-auto flex max-w-6xl items-center justify-between px-5 py-3.5", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("a", { href: "#top", className: "flex items-center gap-2.5", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: logoImg, alt: "Wheels & Vision for All logo", width: 36, height: 36, className: "h-9 w-9 rounded-full object-cover" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-lg font-bold leading-tight tracking-tight", children: [
            "Wheels & Vision",
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "block text-[0.65rem] font-medium uppercase tracking-[0.2em] text-muted-foreground", children: "for All" })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("nav", { className: "hidden items-center gap-6 md:flex", children: [
          nav.map((n) => /* @__PURE__ */ jsxRuntimeExports.jsx("a", { href: n.href, className: "text-sm font-medium text-muted-foreground transition-colors hover:text-foreground", children: t(n.label) }, n.href)),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/health", className: "text-sm font-medium text-muted-foreground transition-colors hover:text-foreground", children: t("nav.health") }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/knowledge", className: "text-sm font-medium text-muted-foreground transition-colors hover:text-foreground", children: t("nav.knowledge") }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(LanguageSwitcher, {}),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { asChild: true, variant: "outline", size: "sm", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/auth", children: t("nav.signIn") }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { asChild: true, variant: "hero", size: "sm", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/book", children: t("nav.bookNow") }) })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("button", { className: "md:hidden", onClick: () => setOpen((v) => !v), "aria-label": "Toggle menu", children: open ? /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "h-6 w-6" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Menu, { className: "h-6 w-6" }) })
      ] }),
      open && /* @__PURE__ */ jsxRuntimeExports.jsxs("nav", { className: "flex flex-col gap-1 border-t border-border/60 bg-background px-5 py-3 md:hidden", children: [
        nav.map((n) => /* @__PURE__ */ jsxRuntimeExports.jsx("a", { href: n.href, onClick: () => setOpen(false), className: "rounded-md px-2 py-2 text-sm font-medium text-muted-foreground hover:bg-muted hover:text-foreground", children: t(n.label) }, n.href)),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/health", onClick: () => setOpen(false), className: "rounded-md px-2 py-2 text-sm font-medium text-muted-foreground hover:bg-muted hover:text-foreground", children: t("nav.health") }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/knowledge", onClick: () => setOpen(false), className: "rounded-md px-2 py-2 text-sm font-medium text-muted-foreground hover:bg-muted hover:text-foreground", children: t("nav.knowledge") }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-2 px-2", children: /* @__PURE__ */ jsxRuntimeExports.jsx(LanguageSwitcher, {}) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { asChild: true, variant: "outline", className: "mt-2", onClick: () => setOpen(false), children: /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/auth", children: t("nav.signIn") }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { asChild: true, variant: "hero", className: "mt-2", onClick: () => setOpen(false), children: /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/book", children: t("nav.bookNow") }) })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("section", { id: "top", className: "relative flex min-h-[92vh] items-center", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: heroImg, alt: "Volunteers helping a smiling man in a wheelchair at golden hour in South Africa", width: 1920, height: 1080, className: "absolute inset-0 h-full w-full object-cover" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute inset-0 bg-[image:var(--gradient-hero)]" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "relative mx-auto w-full max-w-6xl px-5 pt-24", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "max-w-2xl", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "mt-6 animate-in fade-in slide-in-from-bottom-4 text-4xl font-bold leading-[1.05] tracking-tight text-primary-foreground duration-700 [animation-delay:120ms] sm:text-6xl", children: t("hero.title") }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-5 max-w-xl animate-in fade-in slide-in-from-bottom-4 text-lg leading-relaxed text-primary-foreground/90 duration-700 [animation-delay:260ms]", children: t("hero.subtitle") }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-8 flex flex-wrap gap-3 animate-in fade-in slide-in-from-bottom-4 duration-700 [animation-delay:400ms]", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { asChild: true, variant: "hero", size: "lg", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Link, { to: "/book", children: [
            t("hero.book"),
            " ",
            /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowRight, { className: "h-4 w-4 transition-transform group-hover:translate-x-1" })
          ] }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { asChild: true, variant: "heroOutline", size: "lg", children: /* @__PURE__ */ jsxRuntimeExports.jsx("a", { href: "#involved", children: t("hero.support") }) })
        ] })
      ] }) })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("section", { className: "border-b border-border bg-card", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mx-auto max-w-6xl px-5 py-12", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mx-auto max-w-2xl text-center", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-2xl font-bold tracking-tight sm:text-3xl", children: t("services.heading") }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-2 text-muted-foreground", children: t("services.sub") })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mx-auto mt-8 grid max-w-3xl grid-cols-3 gap-3 sm:grid-cols-5", children: [{
        icon: Eye,
        label: "Eye test",
        to: "/book"
      }, {
        icon: Accessibility,
        label: "Wheelchair",
        to: "/book"
      }, {
        icon: Glasses,
        label: "Glasses",
        to: "/book"
      }, {
        icon: Stethoscope,
        label: "Health",
        to: "/health"
      }, {
        icon: HandHeart,
        label: "Donate",
        to: "/involved"
      }].map((q) => q.to === "/involved" ? /* @__PURE__ */ jsxRuntimeExports.jsxs("a", { href: "#involved", className: "hover-lift flex flex-col items-center gap-2 rounded-2xl border border-border bg-background p-3 text-center shadow-[var(--shadow-soft)]", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "flex h-10 w-10 items-center justify-center rounded-xl bg-[image:var(--gradient-primary)] text-primary-foreground", children: /* @__PURE__ */ jsxRuntimeExports.jsx(q.icon, { className: "h-5 w-5" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs font-semibold", children: q.label })
      ] }, q.label) : /* @__PURE__ */ jsxRuntimeExports.jsxs(Link, { to: q.to, className: "hover-lift flex flex-col items-center gap-2 rounded-2xl border border-border bg-background p-3 text-center shadow-[var(--shadow-soft)]", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "flex h-10 w-10 items-center justify-center rounded-xl bg-[image:var(--gradient-primary)] text-primary-foreground", children: /* @__PURE__ */ jsxRuntimeExports.jsx(q.icon, { className: "h-5 w-5" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs font-semibold", children: q.label })
      ] }, q.label)) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-8 grid gap-5 md:grid-cols-3", children: [{
        to: "/book",
        icon: CalendarCheck,
        title: t("services.book.title"),
        text: t("services.book.text")
      }, {
        to: "/knowledge",
        icon: BookOpen,
        title: t("services.knowledge.title"),
        text: t("services.knowledge.text")
      }, {
        to: "/assistant",
        icon: Bot,
        title: t("services.assistant.title"),
        text: t("services.assistant.text")
      }].map((c, i) => /* @__PURE__ */ jsxRuntimeExports.jsx(Reveal, { delay: i * 120, children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Link, { to: c.to, className: "hover-lift group flex h-full flex-col rounded-2xl border border-border bg-background p-6 shadow-[var(--shadow-soft)]", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "flex h-12 w-12 items-center justify-center rounded-xl bg-[image:var(--gradient-primary)] text-primary-foreground transition-transform duration-300 group-hover:scale-110", children: /* @__PURE__ */ jsxRuntimeExports.jsx(c.icon, { className: "h-6 w-6" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "mt-4 text-lg font-bold", children: c.title }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-2 text-sm leading-relaxed text-muted-foreground", children: c.text }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "mt-4 flex items-center gap-1 text-sm font-semibold text-primary", children: [
          t("services.open"),
          " ",
          /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowRight, { className: "h-4 w-4 transition-transform group-hover:translate-x-1" })
        ] })
      ] }) }, c.to)) })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("section", { id: "about", className: "mx-auto max-w-6xl px-5 py-20 sm:py-28", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid items-center gap-12 md:grid-cols-2", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs(Reveal, { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm font-semibold uppercase tracking-[0.2em] text-accent", children: t("about.kicker") }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "mt-3 text-3xl font-bold tracking-tight sm:text-4xl", children: t("about.heading") }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-5 text-lg leading-relaxed text-muted-foreground", children: t("about.p1") }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-4 text-lg leading-relaxed text-muted-foreground", children: t("about.p2") })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-2 gap-4", children: [{
        icon: Accessibility,
        title: t("about.mobility.title"),
        text: t("about.mobility.text")
      }, {
        icon: Eye,
        title: t("about.vision.title"),
        text: t("about.vision.text")
      }, {
        icon: Users,
        title: t("about.community.title"),
        text: t("about.community.text")
      }, {
        icon: HandHeart,
        title: t("about.care.title"),
        text: t("about.care.text")
      }].map((c, i) => /* @__PURE__ */ jsxRuntimeExports.jsxs(Reveal, { delay: i * 120, className: "hover-lift rounded-2xl border border-border bg-card p-6 shadow-[var(--shadow-soft)]", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "flex h-11 w-11 items-center justify-center rounded-xl bg-secondary text-primary", children: /* @__PURE__ */ jsxRuntimeExports.jsx(c.icon, { className: "h-6 w-6" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "mt-4 font-semibold", children: c.title }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-muted-foreground", children: c.text })
      ] }, c.title)) })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("section", { id: "programmes", className: "bg-secondary/50 py-20 sm:py-28", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mx-auto max-w-6xl px-5", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mx-auto max-w-2xl text-center", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm font-semibold uppercase tracking-[0.2em] text-accent", children: t("prog.kicker") }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "mt-3 text-3xl font-bold tracking-tight sm:text-4xl", children: t("prog.heading") })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-14 grid gap-8 md:grid-cols-2", children: [{
        img: mobilityImg,
        icon: Accessibility,
        title: t("prog.wheels.title"),
        text: t("prog.wheels.text"),
        points: [t("prog.wheels.p1"), t("prog.wheels.p2"), t("prog.wheels.p3")]
      }, {
        img: visionImg,
        icon: Glasses,
        title: t("prog.vision.title"),
        text: t("prog.vision.text"),
        points: [t("prog.vision.p1"), t("prog.vision.p2"), t("prog.vision.p3")]
      }].map((p, i) => /* @__PURE__ */ jsxRuntimeExports.jsxs(Reveal, { as: "article", delay: i * 150, className: "hover-lift group overflow-hidden rounded-3xl border border-border bg-card shadow-[var(--shadow-soft)]", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "overflow-hidden", children: /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: p.img, alt: p.title, width: 1200, height: 900, loading: "lazy", className: "h-56 w-full object-cover transition-transform duration-700 group-hover:scale-105" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-7", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "flex h-11 w-11 items-center justify-center rounded-xl bg-[image:var(--gradient-primary)] text-primary-foreground", children: /* @__PURE__ */ jsxRuntimeExports.jsx(p.icon, { className: "h-6 w-6" }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "mt-4 text-xl font-bold", children: p.title }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-2 leading-relaxed text-muted-foreground", children: p.text }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("ul", { className: "mt-5 space-y-2", children: p.points.map((pt) => /* @__PURE__ */ jsxRuntimeExports.jsxs("li", { className: "flex items-start gap-2 text-sm", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Heart, { className: "mt-0.5 h-4 w-4 shrink-0 text-accent" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: pt })
          ] }, pt)) })
        ] })
      ] }, p.title)) })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("section", { className: "mx-auto max-w-6xl px-5 py-16", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mx-auto max-w-2xl text-center", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "flex items-center justify-center gap-2 text-sm font-semibold uppercase tracking-[0.2em] text-accent", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Lightbulb, { className: "h-4 w-4" }),
          " Did you know?"
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "mt-3 text-3xl font-bold tracking-tight sm:text-4xl", children: "Small steps protect mobility & sight" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-10 grid gap-5 md:grid-cols-3", children: [{
        img: visionImg,
        cat: "Eye health",
        title: "Regular eye tests can prevent up to 80% of vision loss."
      }, {
        img: mobilityImg,
        cat: "Mobility",
        title: "A wheelchair should be serviced every 6 months to stay safe."
      }, {
        img: heroImg,
        cat: "Wellbeing",
        title: "Early care for chronic conditions keeps families independent."
      }].map((p, i) => /* @__PURE__ */ jsxRuntimeExports.jsxs(Reveal, { as: "article", delay: i * 120, className: "hover-lift overflow-hidden rounded-2xl border border-border bg-card shadow-[var(--shadow-soft)]", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: p.img, alt: "", loading: "lazy", className: "h-40 w-full object-cover" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-5", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "inline-block rounded-full bg-secondary px-2.5 py-0.5 text-xs font-semibold text-primary", children: p.cat }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-2 font-semibold leading-snug", children: p.title })
        ] })
      ] }, p.title)) })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("section", { id: "impact", className: "mx-auto max-w-6xl px-5 py-20 sm:py-28", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "animate-gradient rounded-3xl bg-[image:var(--gradient-primary)] px-6 py-14 text-primary-foreground shadow-[var(--shadow-elegant)] sm:px-12", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mx-auto max-w-2xl text-center", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-3xl font-bold tracking-tight sm:text-4xl", children: t("impact.heading") }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-3 text-primary-foreground/85", children: t("impact.sub") })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-12 grid grid-cols-2 gap-8 sm:grid-cols-4", children: [{
        stat: "0",
        label: t("impact.reached")
      }, {
        stat: "0",
        label: t("impact.wheelchairs")
      }, {
        stat: "0",
        label: t("impact.eyes")
      }, {
        stat: "0",
        label: t("impact.volunteers")
      }].map((s, i) => /* @__PURE__ */ jsxRuntimeExports.jsxs(Reveal, { delay: i * 120, className: "text-center", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-4xl font-bold sm:text-5xl", children: s.stat }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-2 text-sm text-primary-foreground/80", children: s.label })
      ] }, s.label)) })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("section", { id: "involved", className: "bg-secondary/50 py-20 sm:py-28", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mx-auto max-w-6xl px-5", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mx-auto max-w-2xl text-center", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm font-semibold uppercase tracking-[0.2em] text-accent", children: t("inv.kicker") }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "mt-3 text-3xl font-bold tracking-tight sm:text-4xl", children: t("inv.heading") })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-14 grid gap-6 md:grid-cols-3", children: [{
        icon: HandHeart,
        title: t("inv.donate.title"),
        text: t("inv.donate.text")
      }, {
        icon: Users,
        title: t("inv.volunteer.title"),
        text: t("inv.volunteer.text")
      }, {
        icon: Heart,
        title: t("inv.partner.title"),
        text: t("inv.partner.text")
      }].map((c, i) => /* @__PURE__ */ jsxRuntimeExports.jsxs(Reveal, { delay: i * 120, className: "hover-lift group rounded-2xl border border-border bg-card p-7 shadow-[var(--shadow-soft)]", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "flex h-12 w-12 items-center justify-center rounded-xl bg-secondary text-primary transition-transform duration-300 group-hover:scale-110", children: /* @__PURE__ */ jsxRuntimeExports.jsx(c.icon, { className: "h-6 w-6" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "mt-4 text-lg font-bold", children: c.title }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-2 text-sm leading-relaxed text-muted-foreground", children: c.text })
      ] }, c.title)) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-10 text-center", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { asChild: true, variant: "hero", size: "lg", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("a", { href: "#contact", children: [
        t("inv.cta"),
        " ",
        /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowRight, { className: "h-4 w-4" })
      ] }) }) })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("section", { id: "contact", className: "mx-auto max-w-6xl px-5 py-20 sm:py-28", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid gap-10 md:grid-cols-2", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm font-semibold uppercase tracking-[0.2em] text-accent", children: t("contact.kicker") }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "mt-3 text-3xl font-bold tracking-tight sm:text-4xl", children: t("contact.heading") }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-4 text-lg leading-relaxed text-muted-foreground", children: t("contact.p") }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("ul", { className: "mt-8 space-y-5", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("li", { className: "flex items-start gap-3", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(MapPin, { className: "mt-0.5 h-5 w-5 text-primary" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
              t("contact.based"),
              /* @__PURE__ */ jsxRuntimeExports.jsx("br", {}),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-sm text-muted-foreground", children: t("contact.outreach") })
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("li", { className: "flex items-center gap-3", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Mail, { className: "h-5 w-5 text-primary" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("a", { href: "mailto:info@wheelsandvision.org", className: "hover:text-primary", children: "info@wheelsandvision.org" })
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("form", { onSubmit: (e) => e.preventDefault(), className: "rounded-3xl border border-border bg-card p-7 shadow-[var(--shadow-soft)]", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid gap-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "text-sm font-medium", htmlFor: "name", children: t("contact.name") }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("input", { id: "name", type: "text", required: true, className: "mt-1.5 w-full rounded-lg border border-input bg-background px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-ring" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "text-sm font-medium", htmlFor: "email", children: t("contact.email") }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("input", { id: "email", type: "email", required: true, className: "mt-1.5 w-full rounded-lg border border-input bg-background px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-ring" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "text-sm font-medium", htmlFor: "message", children: t("contact.message") }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("textarea", { id: "message", rows: 4, required: true, className: "mt-1.5 w-full rounded-lg border border-input bg-background px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-ring" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { type: "submit", variant: "hero", size: "lg", children: t("contact.send") })
      ] }) })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("footer", { className: "border-t border-border bg-secondary/40", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mx-auto flex max-w-6xl flex-col items-center justify-between gap-4 px-5 py-8 text-sm text-muted-foreground sm:flex-row", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: logoImg, alt: "Wheels & Vision for All logo", width: 28, height: 28, className: "h-7 w-7 rounded-full object-cover" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-semibold text-foreground", children: "Wheels & Vision for All" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { children: [
        "© ",
        (/* @__PURE__ */ new Date()).getFullYear(),
        " ",
        t("footer.rights")
      ] })
    ] }) })
  ] });
}
export {
  Index as component
};
