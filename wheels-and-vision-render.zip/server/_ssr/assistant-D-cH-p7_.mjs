import { r as reactExports, j as jsxRuntimeExports } from "../_libs/react.mjs";
import { L as Link } from "../_libs/tanstack__react-router.mjs";
import { t as toast } from "../_libs/sonner.mjs";
import { u as useA11y, B as Button } from "./router-Cq4mEwYw.mjs";
import { S as SiteHeader } from "./SiteHeader-xQIsjNcd.mjs";
import { a as LoaderCircle, S as Square, V as Volume2, u as Send, o as CalendarCheck } from "../_libs/lucide-react.mjs";
import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval.mjs";
import "../_libs/seroval-plugins.mjs";
import "node:stream/web";
import "node:stream";
import "../_libs/react-dom.mjs";
import "util";
import "crypto";
import "async_hooks";
import "stream";
import "../_libs/isbot.mjs";
import "../_libs/tanstack__query-core.mjs";
import "../_libs/tanstack__react-query.mjs";
import "./client-Dt-bKJUW.mjs";
import "../_libs/supabase__supabase-js.mjs";
import "../_libs/supabase__postgrest-js.mjs";
import "../_libs/supabase__realtime-js.mjs";
import "../_libs/supabase__phoenix.mjs";
import "../_libs/supabase__storage-js.mjs";
import "../_libs/iceberg-js.mjs";
import "../_libs/supabase__auth-js.mjs";
import "tslib";
import "../_libs/supabase__functions-js.mjs";
import "../_libs/radix-ui__react-slot.mjs";
import "../_libs/radix-ui__react-compose-refs.mjs";
import "../_libs/class-variance-authority.mjs";
import "../_libs/clsx.mjs";
import "../_libs/tailwind-merge.mjs";
import "../_libs/radix-ui__react-switch.mjs";
import "../_libs/radix-ui__primitive.mjs";
import "../_libs/radix-ui__react-context.mjs";
import "../_libs/@radix-ui/react-use-controllable-state+[...].mjs";
import "../_libs/@radix-ui/react-use-layout-effect+[...].mjs";
import "../_libs/radix-ui__react-use-previous.mjs";
import "../_libs/radix-ui__react-use-size.mjs";
import "../_libs/radix-ui__react-primitive.mjs";
import "./logo-CMkK24B0.mjs";
const assistantAvatar = "/assets/assistant-avatar-cYo81opi.png";
const suggestions = ["How do I book an eye test?", "How often should a wheelchair be serviced?", "What are my rights to access as a wheelchair user?", "Where is the nearest hospital for an eye test?"];
const GREETING = {
  role: "assistant",
  content: "Hello! I'm the Wheels & Vision assistant. I can help you book an eye test or wheelchair service, share accessibility information, or answer questions about our work. How can I help you today?"
};
function AssistantPage() {
  const {
    speak,
    stopSpeaking,
    speaking
  } = useA11y();
  const [messages, setMessages] = reactExports.useState([GREETING]);
  const [input, setInput] = reactExports.useState("");
  const [loading, setLoading] = reactExports.useState(false);
  const scrollRef = reactExports.useRef(null);
  const inputRef = reactExports.useRef(null);
  reactExports.useEffect(() => {
    scrollRef.current?.scrollTo({
      top: scrollRef.current.scrollHeight
    });
  }, [messages]);
  reactExports.useEffect(() => {
    inputRef.current?.focus();
  }, [loading]);
  const send = async (text) => {
    const trimmed = text.trim();
    if (!trimmed || loading) return;
    const next = [...messages, {
      role: "user",
      content: trimmed
    }];
    setMessages([...next, {
      role: "assistant",
      content: ""
    }]);
    setInput("");
    setLoading(true);
    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          messages: next
        })
      });
      if (!res.ok || !res.body) {
        const data = await res.json().catch(() => null);
        throw new Error(data?.error ?? "The assistant could not respond.");
      }
      const reader = res.body.getReader();
      const decoder = new TextDecoder();
      let buffer = "";
      let assistantText = "";
      while (true) {
        const {
          done,
          value
        } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, {
          stream: true
        });
        const lines = buffer.split("\n");
        buffer = lines.pop() ?? "";
        for (const line of lines) {
          const trimmedLine = line.trim();
          if (!trimmedLine.startsWith("data:")) continue;
          const payload = trimmedLine.slice(5).trim();
          if (payload === "[DONE]") continue;
          try {
            const json = JSON.parse(payload);
            const delta = json.choices?.[0]?.delta?.content;
            if (delta) {
              assistantText += delta;
              setMessages((prev) => {
                const copy = [...prev];
                copy[copy.length - 1] = {
                  role: "assistant",
                  content: assistantText
                };
                return copy;
              });
            }
          } catch {
          }
        }
      }
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Something went wrong.");
      setMessages((prev) => {
        const copy = [...prev];
        if (copy[copy.length - 1]?.content === "") {
          copy[copy.length - 1] = {
            role: "assistant",
            content: "Sorry, I couldn't respond just now. Please try again in a moment."
          };
        }
        return copy;
      });
    } finally {
      setLoading(false);
    }
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex min-h-screen flex-col bg-background", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(SiteHeader, {}),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("main", { id: "main-content", className: "mx-auto flex w-full max-w-3xl flex-1 flex-col px-5 py-6", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: assistantAvatar, alt: "", width: 48, height: 48, className: "h-12 w-12 rounded-full" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "text-xl font-bold", children: "Wheels & Vision Assistant" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-muted-foreground", children: "Here to help with bookings and accessibility questions." })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { ref: scrollRef, className: "mt-5 flex-1 space-y-4 overflow-y-auto rounded-2xl border border-border bg-card/50 p-4", "aria-live": "polite", "aria-label": "Conversation", children: messages.map((m, i) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `flex gap-3 ${m.role === "user" ? "justify-end" : "justify-start"}`, children: [
        m.role === "assistant" && /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: assistantAvatar, alt: "", width: 32, height: 32, className: "h-8 w-8 shrink-0 rounded-full" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `max-w-[80%] rounded-2xl px-4 py-2.5 text-[0.95rem] leading-relaxed ${m.role === "user" ? "bg-primary text-primary-foreground" : "bg-muted text-foreground"}`, children: [
          m.content || loading && i === messages.length - 1 ? m.content ? /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "whitespace-pre-wrap", children: m.content }) : /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "h-4 w-4 animate-spin" }) : null,
          m.role === "assistant" && m.content && /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { onClick: () => speaking ? stopSpeaking() : speak(m.content), "aria-label": speaking ? "Stop reading" : "Read aloud", className: "mt-1.5 flex items-center gap-1 text-xs font-medium text-muted-foreground hover:text-foreground", children: [
            speaking ? /* @__PURE__ */ jsxRuntimeExports.jsx(Square, { className: "h-3.5 w-3.5" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Volume2, { className: "h-3.5 w-3.5" }),
            speaking ? "Stop" : "Listen"
          ] })
        ] })
      ] }, i)) }),
      messages.length <= 1 && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-4 flex flex-wrap gap-2", children: suggestions.map((s) => /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: () => send(s), className: "rounded-full border border-border bg-card px-3 py-1.5 text-sm text-muted-foreground transition-colors hover:bg-muted hover:text-foreground", children: s }, s)) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("form", { onSubmit: (e) => {
        e.preventDefault();
        send(input);
      }, className: "mt-4 flex items-end gap-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("textarea", { ref: inputRef, value: input, onChange: (e) => setInput(e.target.value), onKeyDown: (e) => {
          if (e.key === "Enter" && !e.shiftKey) {
            e.preventDefault();
            send(input);
          }
        }, rows: 1, placeholder: "Type your message…", "aria-label": "Message", className: "max-h-32 flex-1 resize-none rounded-xl border border-input bg-background px-4 py-3 text-sm outline-none focus-visible:ring-2 focus-visible:ring-ring" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { type: "submit", variant: "hero", size: "icon", disabled: loading || !input.trim(), "aria-label": "Send message", className: "h-12 w-12 shrink-0", children: loading ? /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "h-5 w-5 animate-spin" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Send, { className: "h-5 w-5" }) })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "mt-3 text-center text-xs text-muted-foreground", children: [
        "Ready to book?",
        " ",
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Link, { to: "/book", className: "font-medium text-primary hover:underline", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(CalendarCheck, { className: "mb-0.5 inline h-3.5 w-3.5" }),
          " Go to bookings"
        ] })
      ] })
    ] })
  ] });
}
export {
  AssistantPage as component
};
