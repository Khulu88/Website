import { r as reactExports, j as jsxRuntimeExports } from "../_libs/react.mjs";
import { d as useNavigate } from "../_libs/tanstack__react-router.mjs";
import { u as useQuery } from "../_libs/tanstack__react-query.mjs";
import { t as toast } from "../_libs/sonner.mjs";
import { s as supabase } from "./client-Dt-bKJUW.mjs";
import { a as useAuth, B as Button, c as cn } from "./router-Cq4mEwYw.mjs";
import { S as SiteHeader } from "./SiteHeader-xQIsjNcd.mjs";
import { L as Label, I as Input } from "./label-C2Jd1N73.mjs";
import { E as Eye, A as Accessibility, s as CircleCheck, a as LoaderCircle, N as Navigation, l as MapPin, o as CalendarCheck } from "../_libs/lucide-react.mjs";
import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval.mjs";
import "../_libs/seroval-plugins.mjs";
import "node:stream/web";
import "node:stream";
import "../_libs/react-dom.mjs";
import "util";
import "crypto";
import "async_hooks";
import "stream";
import "../_libs/isbot.mjs";
import "../_libs/tanstack__query-core.mjs";
import "../_libs/supabase__supabase-js.mjs";
import "../_libs/supabase__postgrest-js.mjs";
import "../_libs/supabase__realtime-js.mjs";
import "../_libs/supabase__phoenix.mjs";
import "../_libs/supabase__storage-js.mjs";
import "../_libs/iceberg-js.mjs";
import "../_libs/supabase__auth-js.mjs";
import "tslib";
import "../_libs/supabase__functions-js.mjs";
import "../_libs/radix-ui__react-slot.mjs";
import "../_libs/radix-ui__react-compose-refs.mjs";
import "../_libs/class-variance-authority.mjs";
import "../_libs/clsx.mjs";
import "../_libs/tailwind-merge.mjs";
import "../_libs/radix-ui__react-switch.mjs";
import "../_libs/radix-ui__primitive.mjs";
import "../_libs/radix-ui__react-context.mjs";
import "../_libs/@radix-ui/react-use-controllable-state+[...].mjs";
import "../_libs/@radix-ui/react-use-layout-effect+[...].mjs";
import "../_libs/radix-ui__react-use-previous.mjs";
import "../_libs/radix-ui__react-use-size.mjs";
import "../_libs/radix-ui__react-primitive.mjs";
import "./logo-CMkK24B0.mjs";
import "../_libs/radix-ui__react-label.mjs";
const Textarea = reactExports.forwardRef(
  ({ className, ...props }, ref) => {
    return /* @__PURE__ */ jsxRuntimeExports.jsx(
      "textarea",
      {
        className: cn(
          "flex min-h-[60px] w-full rounded-md border border-input bg-transparent px-3 py-2 text-base shadow-sm placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50 md:text-sm",
          className
        ),
        ref,
        ...props
      }
    );
  }
);
Textarea.displayName = "Textarea";
const services = [{
  value: "eye_test",
  label: "Eye test",
  icon: Eye,
  match: "eye_test"
}, {
  value: "wheelchair_service",
  label: "Wheelchair service",
  icon: Accessibility,
  match: "wheelchair_service"
}, {
  value: "wheelchair_replacement",
  label: "Wheelchair replacement",
  icon: Accessibility,
  match: "wheelchair_replacement"
}];
function distanceKm(lat1, lon1, lat2, lon2) {
  const R = 6371;
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a = Math.sin(dLat / 2) ** 2 + Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * Math.sin(dLon / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}
function BookPage() {
  const {
    user,
    profile
  } = useAuth();
  const navigate = useNavigate();
  const [service, setService] = reactExports.useState("eye_test");
  const [facilityId, setFacilityId] = reactExports.useState(null);
  const [province, setProvince] = reactExports.useState("all");
  const [search, setSearch] = reactExports.useState("");
  const [date, setDate] = reactExports.useState("");
  const [time, setTime] = reactExports.useState("");
  const [notes, setNotes] = reactExports.useState("");
  const [contactName, setContactName] = reactExports.useState("");
  const [coords, setCoords] = reactExports.useState(null);
  const [locating, setLocating] = reactExports.useState(false);
  const [submitting, setSubmitting] = reactExports.useState(false);
  const [done, setDone] = reactExports.useState(false);
  reactExports.useEffect(() => {
    if (profile) {
      setContactName((n) => n || profile.full_name || "");
    }
  }, [profile]);
  const {
    data: facilities = [],
    isLoading
  } = useQuery({
    queryKey: ["facilities"],
    queryFn: async () => {
      const {
        data,
        error
      } = await supabase.from("facilities").select("*");
      if (error) throw error;
      return data;
    }
  });
  const matchedService = services.find((s) => s.value === service);
  const provinces = reactExports.useMemo(() => Array.from(new Set(facilities.map((f) => f.province).filter(Boolean))).sort(), [facilities]);
  const sorted = reactExports.useMemo(() => {
    const q = search.trim().toLowerCase();
    const list = facilities.filter((f) => {
      if (!f.services.includes(matchedService.match)) return false;
      if (province !== "all" && f.province !== province) return false;
      if (q) {
        const haystack = `${f.name} ${f.city ?? ""} ${f.province ?? ""} ${f.address ?? ""}`.toLowerCase();
        if (!haystack.includes(q)) return false;
      }
      return true;
    });
    if (!coords) return list;
    return [...list].sort((a, b) => {
      const da = a.latitude && a.longitude ? distanceKm(coords.lat, coords.lon, a.latitude, a.longitude) : Infinity;
      const db = b.latitude && b.longitude ? distanceKm(coords.lat, coords.lon, b.latitude, b.longitude) : Infinity;
      return da - db;
    });
  }, [facilities, matchedService, coords, province, search]);
  const locate = () => {
    if (!("geolocation" in navigator)) {
      toast.error("Location is not available on this device.");
      return;
    }
    setLocating(true);
    navigator.geolocation.getCurrentPosition((pos) => {
      setCoords({
        lat: pos.coords.latitude,
        lon: pos.coords.longitude
      });
      setLocating(false);
      toast.success("Found your location — showing nearest facilities first.");
    }, () => {
      setLocating(false);
      toast.error("Could not get your location. You can still pick a facility.");
    }, {
      enableHighAccuracy: true,
      timeout: 1e4
    });
  };
  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!user) {
      toast.info("Please sign in to confirm your booking.");
      navigate({
        to: "/auth"
      });
      return;
    }
    if (!facilityId) {
      toast.error("Please choose a facility.");
      return;
    }
    setSubmitting(true);
    try {
      const {
        error
      } = await supabase.from("appointments").insert({
        user_id: user.id,
        facility_id: facilityId,
        service_type: service,
        preferred_date: date,
        preferred_time: time || null,
        notes: notes || null,
        contact_name: contactName || null
      });
      if (error) throw error;
      setDone(true);
      toast.success("Appointment requested! We'll confirm with you soon.");
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Could not book.");
    } finally {
      setSubmitting(false);
    }
  };
  if (done) {
    return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-h-screen bg-background", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(SiteHeader, {}),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("main", { id: "main-content", className: "mx-auto flex max-w-xl flex-col items-center px-5 py-24 text-center", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheck, { className: "h-16 w-16 text-primary" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "mt-6 text-3xl font-bold", children: "Appointment requested" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-3 text-muted-foreground", children: "Thank you. Your request has been received and our team will confirm the date and time with you. You can track its status in your account." }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-8 flex gap-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { variant: "hero", onClick: () => navigate({
            to: "/dashboard"
          }), children: "View my appointments" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { variant: "outline", onClick: () => {
            setDone(false);
            setFacilityId(null);
            setDate("");
          }, children: "Book another" })
        ] })
      ] })
    ] });
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-h-screen bg-background", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(SiteHeader, {}),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("main", { id: "main-content", className: "mx-auto max-w-5xl px-5 py-10 sm:py-14", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "max-w-2xl", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm font-semibold uppercase tracking-[0.2em] text-accent", children: "Appointments" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "mt-2 text-3xl font-bold tracking-tight sm:text-4xl", children: "Book your eye test or wheelchair service" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-3 text-lg text-muted-foreground", children: "Choose a service, find the closest facility, and pick a date. We'll confirm the details with you." })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("form", { onSubmit: handleSubmit, className: "mt-10 grid gap-8 lg:grid-cols-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-7", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("fieldset", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("legend", { className: "text-sm font-semibold", children: "1. What do you need?" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-3 grid gap-3 sm:grid-cols-3", children: services.map((s) => {
              const active = service === s.value;
              return /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { type: "button", onClick: () => {
                setService(s.value);
                setFacilityId(null);
              }, "aria-pressed": active, className: `flex flex-col items-start gap-2 rounded-2xl border p-4 text-left transition-colors ${active ? "border-primary bg-primary/5 ring-1 ring-primary" : "border-border bg-card hover:bg-muted"}`, children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(s.icon, { className: "h-6 w-6 text-primary" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-sm font-semibold", children: s.label })
              ] }, s.value);
            }) })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("fieldset", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("legend", { className: "text-sm font-semibold", children: "2. Choose a facility" }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { type: "button", variant: "outline", size: "sm", onClick: locate, disabled: locating, children: [
                locating ? /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "h-4 w-4 animate-spin" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Navigation, { className: "h-4 w-4" }),
                "Find nearest"
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-3 grid gap-3 sm:grid-cols-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { htmlFor: "province", className: "sr-only", children: "Province" }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("select", { id: "province", value: province, onChange: (e) => {
                  setProvince(e.target.value);
                  setFacilityId(null);
                }, className: "h-10 w-full rounded-md border border-input bg-background px-3 text-sm", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "all", children: "All provinces" }),
                  provinces.map((p) => /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: p, children: p }, p))
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { htmlFor: "facility-search", className: "sr-only", children: "Search by city or facility" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { id: "facility-search", type: "search", value: search, onChange: (e) => setSearch(e.target.value), placeholder: "Search city, town or facility…" })
              ] })
            ] }),
            isLoading ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-4 flex items-center gap-2 text-muted-foreground", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "h-4 w-4 animate-spin" }),
              " Loading facilities…"
            ] }) : sorted.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-4 text-sm text-muted-foreground", children: "No facilities match your search. Try another province or city." }) : /* @__PURE__ */ jsxRuntimeExports.jsx("ul", { className: "mt-3 space-y-3", children: sorted.map((f) => {
              const active = facilityId === f.id;
              const dist = coords && f.latitude && f.longitude ? distanceKm(coords.lat, coords.lon, f.latitude, f.longitude) : null;
              return /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: /* @__PURE__ */ jsxRuntimeExports.jsx("button", { type: "button", onClick: () => setFacilityId(f.id), "aria-pressed": active, className: `w-full rounded-2xl border p-4 text-left transition-colors ${active ? "border-primary bg-primary/5 ring-1 ring-primary" : "border-border bg-card hover:bg-muted"}`, children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start justify-between gap-3", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "font-semibold", children: f.name }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "mt-0.5 flex items-center gap-1 text-sm text-muted-foreground", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(MapPin, { className: "h-3.5 w-3.5" }),
                    [f.address, f.city, f.province].filter(Boolean).join(", ")
                  ] })
                ] }),
                dist !== null && /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "shrink-0 rounded-full bg-secondary px-2.5 py-1 text-xs font-semibold text-secondary-foreground", children: [
                  dist.toFixed(1),
                  " km"
                ] })
              ] }) }) }, f.id);
            }) })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-5 rounded-3xl border border-border bg-card p-6 shadow-[var(--shadow-soft)]", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm font-semibold", children: "3. Your details" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid gap-4 sm:grid-cols-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { htmlFor: "date", children: "Preferred date" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { id: "date", type: "date", required: true, min: (/* @__PURE__ */ new Date()).toISOString().split("T")[0], value: date, onChange: (e) => setDate(e.target.value), className: "mt-1.5" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { htmlFor: "time", children: "Preferred time" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { id: "time", type: "time", value: time, onChange: (e) => setTime(e.target.value), className: "mt-1.5" })
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { htmlFor: "cname", children: "Contact name" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { id: "cname", value: contactName, onChange: (e) => setContactName(e.target.value), className: "mt-1.5" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { htmlFor: "notes", children: "Notes (optional)" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Textarea, { id: "notes", rows: 3, value: notes, onChange: (e) => setNotes(e.target.value), placeholder: "Anything we should know to help you better?", className: "mt-1.5" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { type: "submit", variant: "hero", className: "w-full", disabled: submitting, children: [
            submitting ? /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "h-4 w-4 animate-spin" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(CalendarCheck, { className: "h-4 w-4" }),
            user ? "Request appointment" : "Sign in to book"
          ] }),
          !user && /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-center text-xs text-muted-foreground", children: "You'll be asked to sign in to confirm your booking." })
        ] })
      ] })
    ] })
  ] });
}
export {
  BookPage as component
};
