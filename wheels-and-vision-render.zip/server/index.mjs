globalThis.__nitro_main__ = import.meta.url;
import { N as NodeResponse, s as serve } from "./_libs/srvx.mjs";
import { d as defineHandler, H as HTTPError, t as toEventHandler, a as defineLazyEventHandler, b as H3Core } from "./_libs/h3.mjs";
import { d as decodePath, w as withLeadingSlash, a as withoutTrailingSlash, j as joinURL } from "./_libs/ufo.mjs";
import { promises } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, resolve } from "node:path";
import "node:http";
import "node:stream";
import "node:stream/promises";
import "node:https";
import "node:http2";
import "./_libs/rou3.mjs";
function lazyService(loader) {
  let promise, mod;
  return {
    fetch(req) {
      if (mod) {
        return mod.fetch(req);
      }
      if (!promise) {
        promise = loader().then((_mod) => mod = _mod.default || _mod);
      }
      return promise.then((mod2) => mod2.fetch(req));
    }
  };
}
const services = {
  ["ssr"]: lazyService(() => import("./_ssr/index.mjs"))
};
globalThis.__nitro_vite_envs__ = services;
const headers = ((m) => function headersRouteRule(event) {
  for (const [key2, value] of Object.entries(m.options || {})) {
    event.res.headers.set(key2, value);
  }
});
const assets = {
  "/robots.txt": {
    "type": "text/plain; charset=utf-8",
    "etag": '"17-ZZkCVrbr4BSdjt/K43J0tq8+Qq4"',
    "mtime": "2026-06-10T09:45:30.258Z",
    "size": 23,
    "path": "../public/robots.txt"
  },
  "/assets/SiteHeader-BX49dgYW.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"1058-W03C6TmOep11xqLeIhhFs1TfBLU"',
    "mtime": "2026-06-10T09:45:29.341Z",
    "size": 4184,
    "path": "../public/assets/SiteHeader-BX49dgYW.js"
  },
  "/assets/assistant-avatar-cYo81opi.png": {
    "type": "image/png",
    "etag": '"1cc17-jk5/rDCMiOmFfeDldkJK/RktM48"',
    "mtime": "2026-06-10T09:45:29.341Z",
    "size": 117783,
    "path": "../public/assets/assistant-avatar-cYo81opi.png"
  },
  "/assets/assistant-BatTLN-v.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"146a-ZDnqmZO8SoS63xirN88ppJMhuIg"',
    "mtime": "2026-06-10T09:45:29.341Z",
    "size": 5226,
    "path": "../public/assets/assistant-BatTLN-v.js"
  },
  "/assets/auth-CnaNwDwL.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"1e48-B9VK9nfVqzLNYCjDwIw122PRR9U"',
    "mtime": "2026-06-10T09:45:29.341Z",
    "size": 7752,
    "path": "../public/assets/auth-CnaNwDwL.js"
  },
  "/assets/book-rc4pHANA.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"2402-gZx0pFsE6Gp3g7/iFjQMYkdn2SY"',
    "mtime": "2026-06-10T09:45:29.341Z",
    "size": 9218,
    "path": "../public/assets/book-rc4pHANA.js"
  },
  "/assets/circle-check-Bz5qvzR4.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"ae-jHRwx9qxWBYGF6AXxgu73Gl0mGk"',
    "mtime": "2026-06-10T09:45:29.341Z",
    "size": 174,
    "path": "../public/assets/circle-check-Bz5qvzR4.js"
  },
  "/assets/heart--rmvi2IO.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"103-qPsIi9WIZkD1v/QyHHgVgowXc9k"',
    "mtime": "2026-06-10T09:45:29.342Z",
    "size": 259,
    "path": "../public/assets/heart--rmvi2IO.js"
  },
  "/assets/health-CgDz6j32.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"284b-96+OXYIQlxFVAQhby/+2eV90Z+I"',
    "mtime": "2026-06-10T09:45:29.341Z",
    "size": 10315,
    "path": "../public/assets/health-CgDz6j32.js"
  },
  "/assets/clock-KvcV7mkI.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"a5-Gk36i1fR2ZX+drFYFYcCaw3xXhw"',
    "mtime": "2026-06-10T09:45:29.341Z",
    "size": 165,
    "path": "../public/assets/clock-KvcV7mkI.js"
  },
  "/assets/hero-DgLfjf5t.jpg": {
    "type": "image/jpeg",
    "etag": '"2a216-x/eg1XF91OrDJcNmHyAJSPG8nig"',
    "mtime": "2026-06-10T09:45:29.341Z",
    "size": 172566,
    "path": "../public/assets/hero-DgLfjf5t.jpg"
  },
  "/assets/html2canvas.esm-DXEQVQnt.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"31151-TyUyRNm9rR2JDwpyAxcruTmmr6A"',
    "mtime": "2026-06-10T09:45:29.342Z",
    "size": 201041,
    "path": "../public/assets/html2canvas.esm-DXEQVQnt.js"
  },
  "/assets/index-DJ1uGNec.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"48b9-KMnNN5rLJgGGV91igjlmxkN05L8"',
    "mtime": "2026-06-10T09:45:29.342Z",
    "size": 18617,
    "path": "../public/assets/index-DJ1uGNec.js"
  },
  "/assets/index.es-B4WXIZwx.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"26d23-Vad/7X8uw8ITj2NDKbIaVn4dxUI"',
    "mtime": "2026-06-10T09:45:29.342Z",
    "size": 159011,
    "path": "../public/assets/index.es-B4WXIZwx.js"
  },
  "/assets/knowledge-Dag3HwXt.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"174c-wcI0vbXm5CzvEQsnlNk/10jBI6Q"',
    "mtime": "2026-06-10T09:45:29.341Z",
    "size": 5964,
    "path": "../public/assets/knowledge-Dag3HwXt.js"
  },
  "/assets/label-h-XHWO1e.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"560-7+ibhbY4rdsfi63OOWw92i+skiU"',
    "mtime": "2026-06-10T09:45:29.341Z",
    "size": 1376,
    "path": "../public/assets/label-h-XHWO1e.js"
  },
  "/assets/lightbulb-DRqnwvaF.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"11a-UVvQTa7tco2mqTMiPciPhLCwTKw"',
    "mtime": "2026-06-10T09:45:29.342Z",
    "size": 282,
    "path": "../public/assets/lightbulb-DRqnwvaF.js"
  },
  "/assets/loader-circle-7XyTUlV8.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"8c-TYZPvdNtq/RFA+icwlGMabWgFfs"',
    "mtime": "2026-06-10T09:45:29.341Z",
    "size": 140,
    "path": "../public/assets/loader-circle-7XyTUlV8.js"
  },
  "/assets/logo-BJsb_ajc.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"864-JFxiMK/yKE/J5XGbqWwIENGH+/Y"',
    "mtime": "2026-06-10T09:45:29.342Z",
    "size": 2148,
    "path": "../public/assets/logo-BJsb_ajc.js"
  },
  "/assets/admin-BbLnaVNA.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"75425-9L5xaM7HZ0PVzxr2pRfW0EdIMgk"',
    "mtime": "2026-06-10T09:45:29.342Z",
    "size": 480293,
    "path": "../public/assets/admin-BbLnaVNA.js"
  },
  "/assets/map-pin-BLjlrQkp.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"ff-Mukl11X7mYgfh2L8ao1ORNCwyHQ"',
    "mtime": "2026-06-10T09:45:29.342Z",
    "size": 255,
    "path": "../public/assets/map-pin-BLjlrQkp.js"
  },
  "/assets/dashboard-Dz8mDH3u.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"6043d-0SaVoCQhyUUAczBVKxomSHfF0Aw"',
    "mtime": "2026-06-10T09:45:29.341Z",
    "size": 394301,
    "path": "../public/assets/dashboard-Dz8mDH3u.js"
  },
  "/assets/mobility-D9MXPQpv.jpg": {
    "type": "image/jpeg",
    "etag": '"20e20-Zt+sx5vcNK91IvqS/aK67yAyNks"',
    "mtime": "2026-06-10T09:45:29.341Z",
    "size": 134688,
    "path": "../public/assets/mobility-D9MXPQpv.jpg"
  },
  "/assets/index-BQloYS1p.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"9febf-A4G1sU789N3k/wO0WpVg4DE34Mg"',
    "mtime": "2026-06-10T09:45:29.342Z",
    "size": 655039,
    "path": "../public/assets/index-BQloYS1p.js"
  },
  "/assets/logo-DVvnvtDp.png": {
    "type": "image/png",
    "etag": '"ebebe-+P0Cb5mw/kKp+omWPj2vRwBft7I"',
    "mtime": "2026-06-10T09:45:29.342Z",
    "size": 966334,
    "path": "../public/assets/logo-DVvnvtDp.png"
  },
  "/assets/purify.es-orNEJq1p.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"6871-/XEcB9KTprvZmJxwlmTtjfwCmJI"',
    "mtime": "2026-06-10T09:45:29.342Z",
    "size": 26737,
    "path": "../public/assets/purify.es-orNEJq1p.js"
  },
  "/assets/users-Bu_hiUmF.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"133-IUvWNDd4dGfY6ZoNjZ6F3bimV+Y"',
    "mtime": "2026-06-10T09:45:29.342Z",
    "size": 307,
    "path": "../public/assets/users-Bu_hiUmF.js"
  },
  "/assets/styles-xZkiHtQ_.css": {
    "type": "text/css; charset=utf-8",
    "etag": '"1628e-3I4UQVGQmgWjt1DkpGsMGLb9Kss"',
    "mtime": "2026-06-10T09:45:29.341Z",
    "size": 90766,
    "path": "../public/assets/styles-xZkiHtQ_.css"
  },
  "/assets/volume-2-DbqotZi-.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"1ea-N9fqN8Yn5O6dbVSQJJtRwJ2IIBI"',
    "mtime": "2026-06-10T09:45:29.341Z",
    "size": 490,
    "path": "../public/assets/volume-2-DbqotZi-.js"
  },
  "/assets/vision-Dl5uGTmN.jpg": {
    "type": "image/jpeg",
    "etag": '"16728-rZfbmbQ2eSa/H1IzRj0tYo5UKKk"',
    "mtime": "2026-06-10T09:45:29.324Z",
    "size": 91944,
    "path": "../public/assets/vision-Dl5uGTmN.jpg"
  },
  "/assets/useQuery-Cbz1YlW9.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"2269-a/CPfbDESo4aLacj+cgOVhwSOMc"',
    "mtime": "2026-06-10T09:45:29.342Z",
    "size": 8809,
    "path": "../public/assets/useQuery-Cbz1YlW9.js"
  }
};
function readAsset(id) {
  const serverDir = dirname(fileURLToPath(globalThis.__nitro_main__));
  return promises.readFile(resolve(serverDir, assets[id].path));
}
const publicAssetBases = {};
function isPublicAssetURL(id = "") {
  if (assets[id]) {
    return true;
  }
  for (const base in publicAssetBases) {
    if (id.startsWith(base)) {
      return true;
    }
  }
  return false;
}
function getAsset(id) {
  return assets[id];
}
const METHODS = /* @__PURE__ */ new Set(["HEAD", "GET"]);
const EncodingMap = {
  gzip: ".gz",
  br: ".br",
  zstd: ".zst"
};
const _attSPk = defineHandler((event) => {
  if (event.req.method && !METHODS.has(event.req.method)) {
    return;
  }
  let id = decodePath(withLeadingSlash(withoutTrailingSlash(event.url.pathname)));
  let asset;
  const encodingHeader = event.req.headers.get("accept-encoding") || "";
  const encodings = [...encodingHeader.split(",").map((e) => EncodingMap[e.trim()]).filter(Boolean).sort(), ""];
  for (const encoding of encodings) {
    for (const _id of [id + encoding, joinURL(id, "index.html" + encoding)]) {
      const _asset = getAsset(_id);
      if (_asset) {
        asset = _asset;
        id = _id;
        break;
      }
    }
  }
  if (!asset) {
    if (isPublicAssetURL(id)) {
      event.res.headers.delete("Cache-Control");
      throw new HTTPError({ status: 404 });
    }
    return;
  }
  if (encodings.length > 1) {
    event.res.headers.append("Vary", "Accept-Encoding");
  }
  const ifNotMatch = event.req.headers.get("if-none-match") === asset.etag;
  if (ifNotMatch) {
    event.res.status = 304;
    event.res.statusText = "Not Modified";
    return "";
  }
  const ifModifiedSinceH = event.req.headers.get("if-modified-since");
  const mtimeDate = new Date(asset.mtime);
  if (ifModifiedSinceH && asset.mtime && new Date(ifModifiedSinceH) >= mtimeDate) {
    event.res.status = 304;
    event.res.statusText = "Not Modified";
    return "";
  }
  if (asset.type) {
    event.res.headers.set("Content-Type", asset.type);
  }
  if (asset.etag && !event.res.headers.has("ETag")) {
    event.res.headers.set("ETag", asset.etag);
  }
  if (asset.mtime && !event.res.headers.has("Last-Modified")) {
    event.res.headers.set("Last-Modified", mtimeDate.toUTCString());
  }
  if (asset.encoding && !event.res.headers.has("Content-Encoding")) {
    event.res.headers.set("Content-Encoding", asset.encoding);
  }
  if (asset.size > 0 && !event.res.headers.has("Content-Length")) {
    event.res.headers.set("Content-Length", asset.size.toString());
  }
  return readAsset(id);
});
const findRouteRules = /* @__PURE__ */ (() => {
  const $0 = [{ name: "headers", route: "/assets/**", handler: headers, options: { "cache-control": "public, max-age=31536000, immutable" } }];
  return (m, p) => {
    let r = [];
    if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1) || "/";
    let s = p.split("/"), l = s.length;
    if (l > 1) {
      if (s[1] === "assets") {
        r.unshift({ data: $0, params: { "_": s.slice(2).join("/") } });
      }
    }
    return r;
  };
})();
const _lazy_j21Qvj = defineLazyEventHandler(() => import("./_chunks/ssr-renderer.mjs"));
const findRoute = /* @__PURE__ */ (() => {
  const data = { route: "/**", handler: _lazy_j21Qvj };
  return ((_m, p) => {
    return { data, params: { "_": p.slice(1) } };
  });
})();
const globalMiddleware = [
  toEventHandler(_attSPk)
].filter(Boolean);
const errorHandler$1 = (error, event) => {
  const res = defaultHandler(error, event);
  return new NodeResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
  const unhandled = error.unhandled ?? !HTTPError.isError(error);
  const { status = 500, statusText = "" } = unhandled ? {} : error;
  if (status === 404) {
    const url = event.url || new URL(event.req.url);
    const baseURL = "/";
    if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) {
      return {
        status: 302,
        headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
      };
    }
  }
  const headers2 = new Headers(unhandled ? {} : error.headers);
  headers2.set("content-type", "application/json; charset=utf-8");
  const jsonBody = unhandled ? {
    status,
    unhandled: true
  } : typeof error.toJSON === "function" ? error.toJSON() : {
    status,
    statusText,
    message: error.message
  };
  return {
    status,
    statusText,
    headers: headers2,
    body: {
      error: true,
      ...jsonBody
    }
  };
}
const errorHandlers = [errorHandler$1];
async function errorHandler(error, event) {
  for (const handler of errorHandlers) {
    try {
      const response = await handler(error, event, { defaultHandler });
      if (response) {
        return response;
      }
    } catch (error2) {
      console.error(error2);
    }
  }
}
function createNitroApp() {
  const captureError = (error, errorCtx) => {
    if (errorCtx?.event) {
      const errors = errorCtx.event.req.context?.nitro?.errors;
      if (errors) {
        errors.push({ error, context: errorCtx });
      }
    }
  };
  const h3App = createH3App({
    onError(error, event) {
      return errorHandler(error, event);
    }
  });
  let appHandler = (req) => {
    req.context ||= {};
    req.context.nitro = req.context.nitro || { errors: [] };
    return h3App.fetch(req);
  };
  return {
    fetch: appHandler,
    h3: h3App,
    hooks: void 0,
    captureError
  };
}
function createH3App(config) {
  const h3App = new H3Core(config);
  h3App["~findRoute"] = (event) => findRoute(event.req.method, event.url.pathname);
  h3App["~middleware"].push(...globalMiddleware);
  h3App["~getMiddleware"] = (event, route) => {
    const pathname = event.url.pathname;
    const method = event.req.method;
    const middleware = [];
    const routeRules = getRouteRules(method, pathname);
    event.context.routeRules = routeRules?.routeRules;
    if (routeRules?.routeRuleMiddleware.length) {
      middleware.push(...routeRules.routeRuleMiddleware);
    }
    middleware.push(...h3App["~middleware"]);
    if (route?.data?.middleware?.length) {
      middleware.push(...route.data.middleware);
    }
    return middleware;
  };
  return h3App;
}
const APP_ID = "default";
function useNitroApp() {
  let instance = useNitroApp._instance;
  if (instance) {
    return instance;
  }
  instance = useNitroApp._instance = createNitroApp();
  globalThis.__nitro__ = globalThis.__nitro__ || {};
  globalThis.__nitro__[APP_ID] = instance;
  return instance;
}
function getRouteRules(method, pathname) {
  const m = findRouteRules(method, pathname);
  if (!m?.length) {
    return { routeRuleMiddleware: [] };
  }
  const routeRules = {};
  for (const layer of m) {
    for (const rule of layer.data) {
      const currentRule = routeRules[rule.name];
      if (currentRule) {
        if (rule.options === false) {
          delete routeRules[rule.name];
          continue;
        }
        if (typeof currentRule.options === "object" && typeof rule.options === "object") {
          currentRule.options = {
            ...currentRule.options,
            ...rule.options
          };
        } else {
          currentRule.options = rule.options;
        }
        currentRule.route = rule.route;
        currentRule.params = {
          ...currentRule.params,
          ...layer.params
        };
      } else if (rule.options !== false) {
        routeRules[rule.name] = {
          ...rule,
          params: layer.params
        };
      }
    }
  }
  const middleware = [];
  const orderedRules = Object.values(routeRules).sort((a, b) => (a.handler?.order || 0) - (b.handler?.order || 0));
  for (const rule of orderedRules) {
    if (rule.options === false || !rule.handler) {
      continue;
    }
    middleware.push(rule.handler(rule));
  }
  return {
    routeRules,
    routeRuleMiddleware: middleware
  };
}
function _captureError(error, type) {
  console.error(`[${type}]`, error);
  useNitroApp().captureError?.(error, { tags: [type] });
}
function trapUnhandledErrors() {
  process.on("unhandledRejection", (error) => _captureError(error, "unhandledRejection"));
  process.on("uncaughtException", (error) => _captureError(error, "uncaughtException"));
}
const tracingSrvxPlugins = [];
const _parsedPort = Number.parseInt(process.env.NITRO_PORT ?? process.env.PORT ?? "");
const port = Number.isNaN(_parsedPort) ? 3e3 : _parsedPort;
const host = process.env.NITRO_HOST || process.env.HOST;
const cert = process.env.NITRO_SSL_CERT;
const key = process.env.NITRO_SSL_KEY;
const nitroApp = useNitroApp();
serve({
  port,
  hostname: host,
  tls: cert && key ? {
    cert,
    key
  } : void 0,
  fetch: nitroApp.fetch,
  plugins: [...tracingSrvxPlugins]
});
trapUnhandledErrors();
const nodeServer = {};
export {
  nodeServer as default
};
