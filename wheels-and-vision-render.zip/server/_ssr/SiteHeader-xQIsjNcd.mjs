import { r as reactExports, j as jsxRuntimeExports } from "../_libs/react.mjs";
import { d as useNavigate, L as Link } from "../_libs/tanstack__react-router.mjs";
import { a as useAuth, b as useI18n, B as Button } from "./router-Cq4mEwYw.mjs";
import { l as logoImg, L as LanguageSwitcher } from "./logo-CMkK24B0.mjs";
import { o as CalendarCheck, d as Stethoscope, B as BookOpen, D as Bot, G as Shield, I as LayoutDashboard, J as LogOut, X, K as Menu } from "../_libs/lucide-react.mjs";
const links = [
  { label: "nav.home", to: "/", icon: CalendarCheck },
  { label: "nav.book", to: "/book", icon: CalendarCheck },
  { label: "nav.health", to: "/health", icon: Stethoscope },
  { label: "nav.knowledge", to: "/knowledge", icon: BookOpen },
  { label: "nav.assistant", to: "/assistant", icon: Bot }
];
function SiteHeader() {
  const [open, setOpen] = reactExports.useState(false);
  const { user, isStaff, signOut } = useAuth();
  const { t } = useI18n();
  const navigate = useNavigate();
  const handleSignOut = async () => {
    await signOut();
    navigate({ to: "/" });
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("header", { className: "sticky top-0 z-50 border-b border-border/60 bg-background/90 backdrop-blur-md", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mx-auto flex max-w-6xl items-center justify-between px-5 py-3", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs(Link, { to: "/", className: "flex items-center gap-2.5", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "img",
          {
            src: logoImg,
            alt: "Wheels & Vision for All logo",
            width: 36,
            height: 36,
            className: "h-9 w-9 rounded-full object-cover"
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-base font-bold leading-tight tracking-tight", children: [
          "Wheels & Vision",
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "block text-[0.6rem] font-medium uppercase tracking-[0.2em] text-muted-foreground", children: "for All" })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("nav", { className: "hidden items-center gap-6 md:flex", "aria-label": "Main", children: [
        links.map((l) => /* @__PURE__ */ jsxRuntimeExports.jsx(
          Link,
          {
            to: l.to,
            className: "text-sm font-medium text-muted-foreground transition-colors hover:text-foreground",
            activeProps: { className: "text-foreground font-semibold" },
            children: t(l.label)
          },
          l.to
        )),
        isStaff && /* @__PURE__ */ jsxRuntimeExports.jsxs(
          Link,
          {
            to: "/admin",
            className: "flex items-center gap-1 text-sm font-medium text-muted-foreground transition-colors hover:text-foreground",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Shield, { className: "h-4 w-4" }),
              " ",
              t("nav.admin")
            ]
          }
        )
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "hidden items-center gap-2 md:flex", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(LanguageSwitcher, {}),
        user ? /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { asChild: true, variant: "ghost", size: "sm", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Link, { to: "/dashboard", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(LayoutDashboard, { className: "h-4 w-4" }),
            " ",
            t("nav.account")
          ] }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { variant: "outline", size: "sm", onClick: handleSignOut, children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(LogOut, { className: "h-4 w-4" }),
            " ",
            t("nav.signOut")
          ] })
        ] }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { asChild: true, variant: "hero", size: "sm", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/auth", children: t("nav.signIn") }) })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          className: "md:hidden",
          onClick: () => setOpen((v) => !v),
          "aria-label": "Toggle menu",
          "aria-expanded": open,
          children: open ? /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "h-6 w-6" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Menu, { className: "h-6 w-6" })
        }
      )
    ] }),
    open && /* @__PURE__ */ jsxRuntimeExports.jsxs(
      "nav",
      {
        className: "flex flex-col gap-1 border-t border-border/60 bg-background px-5 py-3 md:hidden",
        "aria-label": "Mobile",
        children: [
          links.map((l) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
            Link,
            {
              to: l.to,
              onClick: () => setOpen(false),
              className: "flex items-center gap-2 rounded-md px-2 py-2.5 text-sm font-medium text-muted-foreground hover:bg-muted hover:text-foreground",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(l.icon, { className: "h-4 w-4" }),
                " ",
                t(l.label)
              ]
            },
            l.to
          )),
          isStaff && /* @__PURE__ */ jsxRuntimeExports.jsxs(
            Link,
            {
              to: "/admin",
              onClick: () => setOpen(false),
              className: "flex items-center gap-2 rounded-md px-2 py-2.5 text-sm font-medium text-muted-foreground hover:bg-muted hover:text-foreground",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Shield, { className: "h-4 w-4" }),
                " ",
                t("nav.admin")
              ]
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-2 flex flex-col gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(LanguageSwitcher, { className: "self-start" }),
            user ? /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { asChild: true, variant: "outline", onClick: () => setOpen(false), children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Link, { to: "/dashboard", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(LayoutDashboard, { className: "h-4 w-4" }),
                " ",
                t("nav.account")
              ] }) }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs(
                Button,
                {
                  variant: "outline",
                  onClick: () => {
                    setOpen(false);
                    handleSignOut();
                  },
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(LogOut, { className: "h-4 w-4" }),
                    " ",
                    t("nav.signOut")
                  ]
                }
              )
            ] }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { asChild: true, variant: "hero", onClick: () => setOpen(false), children: /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/auth", children: t("nav.signIn") }) })
          ] })
        ]
      }
    )
  ] });
}
export {
  SiteHeader as S
};
