import { j as jsxRuntimeExports } from "../_libs/react.mjs";
import { b as useI18n, l as languages } from "./router-Cq4mEwYw.mjs";
import { Z as Globe } from "../_libs/lucide-react.mjs";
function LanguageSwitcher({ className = "" }) {
  const { lang, setLang } = useI18n();
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(
    "div",
    {
      className: `inline-flex items-center gap-1 rounded-full border border-border bg-background p-0.5 ${className}`,
      role: "group",
      "aria-label": "Select language",
      children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Globe, { className: "ml-1.5 h-3.5 w-3.5 text-muted-foreground", "aria-hidden": true }),
        languages.map((l) => /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: () => setLang(l.code),
            "aria-pressed": lang === l.code,
            "aria-label": `Switch to ${l.label}`,
            className: `rounded-full px-2.5 py-1 text-xs font-semibold transition-colors ${lang === l.code ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground"}`,
            children: l.short
          },
          l.code
        ))
      ]
    }
  );
}
const logoImg = "/assets/logo-DVvnvtDp.png";
export {
  LanguageSwitcher as L,
  logoImg as l
};
