import { r as reactExports, j as jsxRuntimeExports } from "../_libs/react.mjs";
import { u as useQuery } from "../_libs/tanstack__react-query.mjs";
import { s as supabase } from "./client-Dt-bKJUW.mjs";
import { u as useA11y, B as Button } from "./router-Cq4mEwYw.mjs";
import { S as SiteHeader } from "./SiteHeader-xQIsjNcd.mjs";
import "../_libs/sonner.mjs";
import { L as Lightbulb, a as LoaderCircle, B as BookOpen, S as Square, V as Volume2, b as CirclePlay } from "../_libs/lucide-react.mjs";
import "../_libs/tanstack__query-core.mjs";
import "../_libs/supabase__supabase-js.mjs";
import "../_libs/supabase__postgrest-js.mjs";
import "../_libs/supabase__realtime-js.mjs";
import "../_libs/supabase__phoenix.mjs";
import "../_libs/supabase__storage-js.mjs";
import "../_libs/iceberg-js.mjs";
import "../_libs/supabase__auth-js.mjs";
import "tslib";
import "../_libs/supabase__functions-js.mjs";
import "../_libs/tanstack__react-router.mjs";
import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval.mjs";
import "../_libs/seroval-plugins.mjs";
import "node:stream/web";
import "node:stream";
import "../_libs/react-dom.mjs";
import "util";
import "crypto";
import "async_hooks";
import "stream";
import "../_libs/isbot.mjs";
import "../_libs/radix-ui__react-slot.mjs";
import "../_libs/radix-ui__react-compose-refs.mjs";
import "../_libs/class-variance-authority.mjs";
import "../_libs/clsx.mjs";
import "../_libs/tailwind-merge.mjs";
import "../_libs/radix-ui__react-switch.mjs";
import "../_libs/radix-ui__primitive.mjs";
import "../_libs/radix-ui__react-context.mjs";
import "../_libs/@radix-ui/react-use-controllable-state+[...].mjs";
import "../_libs/@radix-ui/react-use-layout-effect+[...].mjs";
import "../_libs/radix-ui__react-use-previous.mjs";
import "../_libs/radix-ui__react-use-size.mjs";
import "../_libs/radix-ui__react-primitive.mjs";
import "./logo-CMkK24B0.mjs";
const categoryLabels = {
  all: "All topics",
  eye_health: "Eye health",
  mobility: "Mobility",
  rights: "Rights & access",
  general: "General"
};
const videos = [{
  id: "v1",
  title: "What happens during an eye exam",
  description: "A friendly walkthrough of a routine eye exam, so you know exactly what to expect at your appointment.",
  category: "Eye screening",
  youtubeId: "jN-Eq5A89ME"
}, {
  id: "v2",
  title: "Eye examination & vision assessment guide",
  description: "A clear demonstration of how vision is tested and assessed step by step.",
  category: "Eye screening",
  youtubeId: "YqL6IMGE5os"
}, {
  id: "v3",
  title: "Wheelchair mobility 101: how to push a wheelchair",
  description: "Learn safe pushing technique and good form from an experienced wheelchair user.",
  category: "Wheelchair support",
  youtubeId: "QLQTz2SPJ9I"
}, {
  id: "v4",
  title: "Safe wheelchair transfers",
  description: "Learn safe transfer techniques to move in and out of a wheelchair with confidence and reduce the risk of falls.",
  category: "Wheelchair support",
  youtubeId: "i_0A7OZ6I4s"
}];
function KnowledgePage() {
  const {
    speak,
    stopSpeaking,
    speaking
  } = useA11y();
  const [category, setCategory] = reactExports.useState("all");
  const [activeId, setActiveId] = reactExports.useState(null);
  const {
    data: posts = [],
    isLoading
  } = useQuery({
    queryKey: ["knowledge"],
    queryFn: async () => {
      const {
        data,
        error
      } = await supabase.from("knowledge_posts").select("*").eq("published", true).order("created_at", {
        ascending: false
      });
      if (error) throw error;
      return data;
    }
  });
  const categories = reactExports.useMemo(() => {
    const set = new Set(posts.map((p) => p.category));
    return ["all", ...Array.from(set)];
  }, [posts]);
  const filtered = category === "all" ? posts : posts.filter((p) => p.category === category);
  const handleSpeak = (post) => {
    if (speaking && activeId === post.id) {
      stopSpeaking();
      setActiveId(null);
      return;
    }
    setActiveId(post.id);
    speak(`${post.title}. ${post.summary ?? ""}. ${post.content}`);
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-h-screen bg-background", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(SiteHeader, {}),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("main", { id: "main-content", className: "mx-auto max-w-6xl px-5 py-10 sm:py-14", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "max-w-2xl", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "flex items-center gap-2 text-sm font-semibold uppercase tracking-[0.2em] text-accent", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Lightbulb, { className: "h-4 w-4" }),
          " Did you know?"
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "mt-2 text-3xl font-bold tracking-tight sm:text-4xl", children: "Accessibility Knowledge Hub" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-3 text-lg text-muted-foreground", children: "Clear, practical information on eye care, mobility, and your rights. Read it, or press the speaker to have it read aloud." })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-8 flex flex-wrap gap-2", role: "tablist", "aria-label": "Topics", children: categories.map((c) => /* @__PURE__ */ jsxRuntimeExports.jsx("button", { role: "tab", "aria-selected": category === c, onClick: () => setCategory(c), className: `rounded-full border px-4 py-2 text-sm font-medium transition-colors ${category === c ? "border-primary bg-primary text-primary-foreground" : "border-border bg-card hover:bg-muted"}`, children: categoryLabels[c] ?? c }, c)) }),
      isLoading ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-10 flex items-center gap-2 text-muted-foreground", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "h-4 w-4 animate-spin" }),
        " Loading articles…"
      ] }) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-8 grid gap-6 md:grid-cols-2 lg:grid-cols-3", children: filtered.map((post) => /* @__PURE__ */ jsxRuntimeExports.jsxs("article", { className: "hover-lift flex flex-col rounded-2xl border border-border bg-card p-6 shadow-[var(--shadow-soft)]", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "inline-flex items-center gap-1 rounded-full bg-secondary px-2.5 py-1 text-xs font-semibold text-secondary-foreground", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(BookOpen, { className: "h-3 w-3" }),
            categoryLabels[post.category] ?? post.category
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { type: "button", variant: "ghost", size: "icon", onClick: () => handleSpeak(post), "aria-label": speaking && activeId === post.id ? `Stop reading ${post.title}` : `Read aloud: ${post.title}`, children: speaking && activeId === post.id ? /* @__PURE__ */ jsxRuntimeExports.jsx(Square, { className: "h-5 w-5" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Volume2, { className: "h-5 w-5" }) })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "mt-3 text-lg font-bold leading-snug", children: post.title }),
        post.summary && /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-2 font-medium text-foreground/80", children: post.summary }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-3 text-sm leading-relaxed text-muted-foreground", children: post.content })
      ] }, post.id)) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("section", { className: "mt-16", "aria-labelledby": "video-heading", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "max-w-2xl", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "flex items-center gap-2 text-sm font-semibold uppercase tracking-[0.2em] text-accent", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(CirclePlay, { className: "h-4 w-4" }),
            " Watch & learn"
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { id: "video-heading", className: "mt-2 text-2xl font-bold tracking-tight sm:text-3xl", children: "Educational video clips" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-3 text-lg text-muted-foreground", children: "Short, captioned videos on eye screenings and wheelchair support. Turn on captions using the CC button in each player." })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-8 grid gap-6 md:grid-cols-2", children: videos.map((video) => /* @__PURE__ */ jsxRuntimeExports.jsxs("article", { className: "flex flex-col overflow-hidden rounded-2xl border border-border bg-card shadow-[var(--shadow-soft)]", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "aspect-video w-full bg-muted", children: /* @__PURE__ */ jsxRuntimeExports.jsx("iframe", { className: "h-full w-full", src: `https://www.youtube-nocookie.com/embed/${video.youtubeId}?cc_load_policy=1`, title: video.title, loading: "lazy", allow: "accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture", allowFullScreen: true }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col p-6", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "inline-flex w-fit items-center gap-1 rounded-full bg-secondary px-2.5 py-1 text-xs font-semibold text-secondary-foreground", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(CirclePlay, { className: "h-3 w-3" }),
              video.category
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "mt-3 text-lg font-bold leading-snug", children: video.title }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-2 text-sm leading-relaxed text-muted-foreground", children: video.description })
          ] })
        ] }, video.id)) })
      ] })
    ] })
  ] });
}
export {
  KnowledgePage as component
};
