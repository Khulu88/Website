import { r as reactExports, j as jsxRuntimeExports } from "../_libs/react.mjs";
import { d as useNavigate, L as Link } from "../_libs/tanstack__react-router.mjs";
import { a as useQueryClient, u as useQuery } from "../_libs/tanstack__react-query.mjs";
import { t as toast } from "../_libs/sonner.mjs";
import { s as supabase } from "./client-Dt-bKJUW.mjs";
import { a as useAuth, B as Button } from "./router-Cq4mEwYw.mjs";
import { S as SiteHeader } from "./SiteHeader-xQIsjNcd.mjs";
import { L as Label, I as Input } from "./label-C2Jd1N73.mjs";
import { j as jspdf_node_minExports } from "../_libs/jspdf.mjs";
import { a as LoaderCircle, p as Plus, o as CalendarCheck, A as Accessibility, E as Eye, n as Clock, F as FileDown, q as CircleX, r as User } from "../_libs/lucide-react.mjs";
import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval.mjs";
import "../_libs/seroval-plugins.mjs";
import "node:stream/web";
import "node:stream";
import "../_libs/react-dom.mjs";
import "util";
import "crypto";
import "async_hooks";
import "stream";
import "../_libs/isbot.mjs";
import "../_libs/tanstack__query-core.mjs";
import "../_libs/supabase__supabase-js.mjs";
import "../_libs/supabase__postgrest-js.mjs";
import "../_libs/supabase__realtime-js.mjs";
import "../_libs/supabase__phoenix.mjs";
import "../_libs/supabase__storage-js.mjs";
import "../_libs/iceberg-js.mjs";
import "../_libs/supabase__auth-js.mjs";
import "tslib";
import "../_libs/supabase__functions-js.mjs";
import "../_libs/radix-ui__react-slot.mjs";
import "../_libs/radix-ui__react-compose-refs.mjs";
import "../_libs/class-variance-authority.mjs";
import "../_libs/clsx.mjs";
import "../_libs/tailwind-merge.mjs";
import "../_libs/radix-ui__react-switch.mjs";
import "../_libs/radix-ui__primitive.mjs";
import "../_libs/radix-ui__react-context.mjs";
import "../_libs/@radix-ui/react-use-controllable-state+[...].mjs";
import "../_libs/@radix-ui/react-use-layout-effect+[...].mjs";
import "../_libs/radix-ui__react-use-previous.mjs";
import "../_libs/radix-ui__react-use-size.mjs";
import "../_libs/radix-ui__react-primitive.mjs";
import "./logo-CMkK24B0.mjs";
import "../_libs/radix-ui__react-label.mjs";
import "fs";
import "path";
import "../_libs/fflate.mjs";
import "../_libs/fast-png.mjs";
import "../_libs/iobuffer.mjs";
import "../_libs/pako.mjs";
import "../_libs/html2canvas.mjs";
import "../_libs/dompurify.mjs";
import "../_libs/canvg.mjs";
import "../_libs/core-js.mjs";
import "../_libs/babel__runtime.mjs";
import "../_libs/raf.mjs";
import "../_libs/performance-now.mjs";
import "../_libs/rgbcolor.mjs";
import "../_libs/svg-pathdata.mjs";
import "../_libs/stackblur-canvas.mjs";
const PRIMARY = [31, 111, 136];
const GLOW = [63, 160, 189];
const FG = [26, 46, 54];
const MUTED = [120, 125, 135];
const WHITE = [255, 255, 255];
function exportReceiptPDF(appt) {
  const pageW = 360;
  const pageH = 520;
  const doc = new jspdf_node_minExports.jsPDF({ unit: "pt", format: [pageW, pageH] });
  doc.setFillColor(252, 250, 244);
  doc.rect(0, 0, pageW, pageH, "F");
  doc.setFillColor(...PRIMARY);
  doc.rect(0, 0, pageW, 86, "F");
  doc.setFillColor(...GLOW);
  doc.rect(0, 86, pageW, 4, "F");
  doc.setTextColor(...WHITE);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(18);
  doc.text("Wheels & Vision", 24, 40);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(9);
  doc.text("Mobility & Sight for All", 24, 56);
  doc.setFontSize(8);
  doc.text("APPOINTMENT RECEIPT", pageW - 24, 40, { align: "right" });
  doc.setFont("helvetica", "bold");
  doc.setFontSize(11);
  doc.text(appt.reference, pageW - 24, 58, { align: "right" });
  const cardX = 24;
  let y = 130;
  const cardW = pageW - 48;
  doc.setDrawColor(210, 215, 225);
  doc.setFillColor(...WHITE);
  doc.roundedRect(cardX, 110, cardW, pageH - 170, 14, 14, "FD");
  const rows = [
    ["Status", appt.status],
    ["Service", appt.serviceLabel],
    ["Facility", appt.facility],
    ["Location", appt.location],
    ["Date", appt.date],
    ["Time", appt.time]
  ];
  if (appt.fullName) rows.unshift(["Name", appt.fullName]);
  const labelX = cardX + 20;
  const valueX = pageW - cardX - 20;
  rows.forEach(([label, value]) => {
    doc.setTextColor(...MUTED);
    doc.setFont("helvetica", "normal");
    doc.setFontSize(9);
    doc.text(label.toUpperCase(), labelX, y);
    doc.setTextColor(...FG);
    doc.setFont("helvetica", "bold");
    doc.setFontSize(12);
    doc.text(value || "—", valueX, y, { align: "right" });
    y += 18;
    doc.setDrawColor(235, 238, 242);
    doc.setLineDashPattern([2, 2], 0);
    doc.line(labelX, y - 6, valueX, y - 6);
    doc.setLineDashPattern([], 0);
    y += 10;
  });
  doc.setTextColor(...MUTED);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(8);
  doc.text(
    `Issued: ${(/* @__PURE__ */ new Date()).toLocaleString()}`,
    pageW / 2,
    pageH - 44,
    { align: "center" }
  );
  doc.text(
    "Wheels & Vision for All — wheelsandvision.org",
    pageW / 2,
    pageH - 30,
    { align: "center" }
  );
  doc.save(`WheelsVision-Receipt-${appt.reference}.pdf`);
}
const serviceLabels = {
  eye_test: {
    label: "Eye test",
    icon: Eye
  },
  wheelchair_service: {
    label: "Wheelchair service",
    icon: Accessibility
  },
  wheelchair_replacement: {
    label: "Wheelchair replacement",
    icon: Accessibility
  }
};
const statusStyles = {
  pending: "bg-amber-100 text-amber-800",
  confirmed: "bg-emerald-100 text-emerald-800",
  completed: "bg-sky-100 text-sky-800",
  cancelled: "bg-rose-100 text-rose-800"
};
function DashboardPage() {
  const {
    user,
    profile,
    loading,
    refresh
  } = useAuth();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [fullName, setFullName] = reactExports.useState("");
  const [savingProfile, setSavingProfile] = reactExports.useState(false);
  reactExports.useEffect(() => {
    if (!loading && !user) navigate({
      to: "/auth"
    });
  }, [loading, user, navigate]);
  reactExports.useEffect(() => {
    if (profile) {
      setFullName(profile.full_name ?? "");
    }
  }, [profile]);
  const {
    data: appointments = [],
    isLoading
  } = useQuery({
    queryKey: ["my-appointments", user?.id],
    enabled: !!user,
    queryFn: async () => {
      const {
        data,
        error
      } = await supabase.from("appointments").select("*, facilities(name, city)").order("preferred_date", {
        ascending: false
      });
      if (error) throw error;
      return data;
    }
  });
  const cancel = async (id) => {
    const {
      error
    } = await supabase.from("appointments").update({
      status: "cancelled"
    }).eq("id", id);
    if (error) {
      toast.error("Could not cancel.");
      return;
    }
    toast.success("Appointment cancelled.");
    queryClient.invalidateQueries({
      queryKey: ["my-appointments"]
    });
  };
  const saveProfile = async (e) => {
    e.preventDefault();
    if (!user) return;
    setSavingProfile(true);
    const {
      error
    } = await supabase.from("profiles").update({
      full_name: fullName
    }).eq("id", user.id);
    setSavingProfile(false);
    if (error) {
      toast.error("Could not save profile.");
      return;
    }
    toast.success("Profile updated.");
    refresh();
  };
  if (loading || !user) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex min-h-screen items-center justify-center", children: /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "h-6 w-6 animate-spin text-primary" }) });
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-h-screen bg-background", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(SiteHeader, {}),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("main", { id: "main-content", className: "mx-auto max-w-5xl px-5 py-10", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center justify-between gap-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("h1", { className: "text-3xl font-bold tracking-tight", children: [
            "Hello",
            profile?.full_name ? `, ${profile.full_name.split(" ")[0]}` : ""
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-1 text-muted-foreground", children: "Manage your appointments and details." })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { asChild: true, variant: "hero", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Link, { to: "/book", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Plus, { className: "h-4 w-4" }),
          " New booking"
        ] }) })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-8 grid gap-8 lg:grid-cols-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("section", { className: "lg:col-span-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-lg font-bold", children: "My appointments" }),
          isLoading ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-4 flex items-center gap-2 text-muted-foreground", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "h-4 w-4 animate-spin" }),
            " Loading…"
          ] }) : appointments.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-4 rounded-2xl border border-dashed border-border p-8 text-center", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(CalendarCheck, { className: "mx-auto h-10 w-10 text-muted-foreground" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-3 font-medium", children: "No appointments yet" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-1 text-sm text-muted-foreground", children: "Book an eye test or wheelchair service to get started." }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { asChild: true, variant: "hero", className: "mt-4", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/book", children: "Book now" }) })
          ] }) : /* @__PURE__ */ jsxRuntimeExports.jsx("ul", { className: "mt-4 space-y-3", children: appointments.map((a) => {
            const meta = serviceLabels[a.service_type];
            const Icon = meta?.icon ?? CalendarCheck;
            return /* @__PURE__ */ jsxRuntimeExports.jsxs("li", { className: "rounded-2xl border border-border bg-card p-5 shadow-[var(--shadow-soft)]", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-start justify-between gap-3", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-3", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "flex h-11 w-11 items-center justify-center rounded-xl bg-secondary text-primary", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Icon, { className: "h-5 w-5" }) }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "font-semibold", children: meta?.label ?? a.service_type }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-sm text-muted-foreground", children: [
                      a.facilities?.name ?? "Facility to be confirmed",
                      a.facilities?.city ? `, ${a.facilities.city}` : ""
                    ] }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "mt-1 flex items-center gap-1 text-sm text-muted-foreground", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(Clock, { className: "h-3.5 w-3.5" }),
                      new Date(a.preferred_date).toLocaleDateString("en-ZA", {
                        day: "numeric",
                        month: "long",
                        year: "numeric"
                      }),
                      a.preferred_time ? ` · ${a.preferred_time}` : ""
                    ] })
                  ] })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: `rounded-full px-2.5 py-1 text-xs font-semibold capitalize ${statusStyles[a.status] ?? "bg-muted text-foreground"}`, children: a.status })
              ] }),
              a.notes && /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-3 rounded-lg bg-muted/60 px-3 py-2 text-sm text-muted-foreground", children: a.notes }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-3 flex flex-wrap items-center gap-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { variant: "outline", size: "sm", onClick: () => exportReceiptPDF({
                  reference: `WV-${a.id.slice(0, 6).toUpperCase()}`,
                  status: a.status.charAt(0).toUpperCase() + a.status.slice(1),
                  serviceLabel: meta?.label ?? a.service_type,
                  facility: a.facilities?.name ?? "To be confirmed",
                  location: a.facilities?.city ?? "South Africa",
                  date: new Date(a.preferred_date).toLocaleDateString("en-ZA", {
                    day: "numeric",
                    month: "long",
                    year: "numeric"
                  }),
                  time: a.preferred_time ?? "To be confirmed",
                  fullName: profile?.full_name ?? void 0
                }), children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(FileDown, { className: "h-4 w-4" }),
                  " Receipt"
                ] }),
                a.status !== "cancelled" && a.status !== "completed" && /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { variant: "ghost", size: "sm", className: "text-destructive hover:text-destructive", onClick: () => cancel(a.id), children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(CircleX, { className: "h-4 w-4" }),
                  " Cancel"
                ] })
              ] })
            ] }, a.id);
          }) })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("section", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("h2", { className: "flex items-center gap-2 text-lg font-bold", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(User, { className: "h-5 w-5" }),
            " My details"
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("form", { onSubmit: saveProfile, className: "mt-4 space-y-4 rounded-2xl border border-border bg-card p-5 shadow-[var(--shadow-soft)]", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { htmlFor: "dn", children: "Full name" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { id: "dn", value: fullName, onChange: (e) => setFullName(e.target.value), className: "mt-1.5" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { children: "Email" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: user.email ?? "", disabled: true, className: "mt-1.5" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { type: "submit", variant: "hero", className: "w-full", disabled: savingProfile, children: [
              savingProfile && /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "h-4 w-4 animate-spin" }),
              "Save details"
            ] })
          ] })
        ] })
      ] })
    ] })
  ] });
}
export {
  DashboardPage as component
};
