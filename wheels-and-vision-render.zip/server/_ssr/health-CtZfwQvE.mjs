import { r as reactExports, j as jsxRuntimeExports } from "../_libs/react.mjs";
import { L as Link } from "../_libs/tanstack__react-router.mjs";
import { S as SiteHeader } from "./SiteHeader-xQIsjNcd.mjs";
import { B as Button } from "./router-Cq4mEwYw.mjs";
import "../_libs/sonner.mjs";
import { c as Search, H as HeartPulse, d as Stethoscope, e as Baby, f as Brain, g as Activity, h as Bone, i as Scan, j as Sparkles, k as CircleAlert, l as MapPin, m as Star, n as Clock, o as CalendarCheck } from "../_libs/lucide-react.mjs";
import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval.mjs";
import "../_libs/seroval-plugins.mjs";
import "node:stream/web";
import "node:stream";
import "../_libs/react-dom.mjs";
import "util";
import "crypto";
import "async_hooks";
import "stream";
import "../_libs/isbot.mjs";
import "./logo-CMkK24B0.mjs";
import "../_libs/tanstack__query-core.mjs";
import "../_libs/tanstack__react-query.mjs";
import "./client-Dt-bKJUW.mjs";
import "../_libs/supabase__supabase-js.mjs";
import "../_libs/supabase__postgrest-js.mjs";
import "../_libs/supabase__realtime-js.mjs";
import "../_libs/supabase__phoenix.mjs";
import "../_libs/supabase__storage-js.mjs";
import "../_libs/iceberg-js.mjs";
import "../_libs/supabase__auth-js.mjs";
import "tslib";
import "../_libs/supabase__functions-js.mjs";
import "../_libs/radix-ui__react-slot.mjs";
import "../_libs/radix-ui__react-compose-refs.mjs";
import "../_libs/class-variance-authority.mjs";
import "../_libs/clsx.mjs";
import "../_libs/tailwind-merge.mjs";
import "../_libs/radix-ui__react-switch.mjs";
import "../_libs/radix-ui__primitive.mjs";
import "../_libs/radix-ui__react-context.mjs";
import "../_libs/@radix-ui/react-use-controllable-state+[...].mjs";
import "../_libs/@radix-ui/react-use-layout-effect+[...].mjs";
import "../_libs/radix-ui__react-use-previous.mjs";
import "../_libs/radix-ui__react-use-size.mjs";
import "../_libs/radix-ui__react-primitive.mjs";
const categories = [{
  id: "all",
  label: "All",
  icon: HeartPulse
}, {
  id: "gp",
  label: "GP / Paediatricians",
  icon: Stethoscope
}, {
  id: "gynae",
  label: "Gynaecologists",
  icon: Baby
}, {
  id: "mental",
  label: "Mental well-being",
  icon: Brain
}, {
  id: "physio",
  label: "Physiotherapists",
  icon: Activity
}, {
  id: "chiro",
  label: "Chiropractors",
  icon: Bone
}, {
  id: "radio",
  label: "Radiologists",
  icon: Scan
}, {
  id: "derm",
  label: "Dermatologists",
  icon: Sparkles
}];
const providers = [{
  name: "Dr. Naledi Mokoena",
  cat: "gp",
  specialty: "Family GP & Paediatrics",
  province: "KwaZulu-Natal",
  city: "Durban",
  rating: 4.9,
  nextSlot: "Today · 14:30"
}, {
  name: "Dr. Lerato Khumalo",
  cat: "gp",
  specialty: "General Practitioner",
  province: "Gauteng",
  city: "Johannesburg",
  rating: 4.7,
  nextSlot: "Today · 16:00"
}, {
  name: "Dr. Sipho Dlamini",
  cat: "gp",
  specialty: "Family GP",
  province: "Eastern Cape",
  city: "Gqeberha",
  rating: 4.6,
  nextSlot: "Tomorrow · 08:30"
}, {
  name: "Dr. Aisha Patel",
  cat: "gynae",
  specialty: "Gynaecologist & Obstetrician",
  province: "KwaZulu-Natal",
  city: "Durban",
  rating: 4.8,
  nextSlot: "Tomorrow · 09:00"
}, {
  name: "Dr. Helena Botha",
  cat: "gynae",
  specialty: "Gynaecologist",
  province: "Western Cape",
  city: "Cape Town",
  rating: 4.9,
  nextSlot: "Thu · 11:30"
}, {
  name: "Sanele Dube, MSocSci",
  cat: "mental",
  specialty: "Counsellor — anxiety & trauma",
  province: "Gauteng",
  city: "Pretoria",
  rating: 5,
  nextSlot: "Today · 17:15"
}, {
  name: "SADAG Helpline",
  cat: "mental",
  specialty: "24/7 mental health support (0800 567 567)",
  province: "National",
  city: "Free helpline",
  rating: 4.9,
  nextSlot: "Available now"
}, {
  name: "Thandi Ngubane PT",
  cat: "physio",
  specialty: "Sports & post-op rehab",
  province: "Free State",
  city: "Bloemfontein",
  rating: 4.7,
  nextSlot: "Thu · 11:00"
}, {
  name: "Karabo Mahlangu PT",
  cat: "physio",
  specialty: "Neuro & mobility rehab",
  province: "Gauteng",
  city: "Johannesburg",
  rating: 4.8,
  nextSlot: "Fri · 13:00"
}, {
  name: "Dr. Marco van Wyk",
  cat: "chiro",
  specialty: "Chiropractor — spine & posture",
  province: "Western Cape",
  city: "Cape Town",
  rating: 4.6,
  nextSlot: "Tomorrow · 15:45"
}, {
  name: "Coastal Radiology",
  cat: "radio",
  specialty: "X-ray, MRI & ultrasound",
  province: "KwaZulu-Natal",
  city: "Durban",
  rating: 4.8,
  nextSlot: "Walk-in · today"
}, {
  name: "Highveld Imaging",
  cat: "radio",
  specialty: "CT, MRI & ultrasound",
  province: "Gauteng",
  city: "Pretoria",
  rating: 4.7,
  nextSlot: "Walk-in · today"
}, {
  name: "Dr. Priya Naidoo",
  cat: "derm",
  specialty: "Dermatologist — skin, acne & eczema",
  province: "KwaZulu-Natal",
  city: "Durban",
  rating: 4.9,
  nextSlot: "Fri · 10:30"
}, {
  name: "Dr. Anele Mbeki",
  cat: "derm",
  specialty: "Dermatologist",
  province: "Eastern Cape",
  city: "East London",
  rating: 4.7,
  nextSlot: "Mon · 09:15"
}];
function HealthPage() {
  const [active, setActive] = reactExports.useState("all");
  const [query, setQuery] = reactExports.useState("");
  const filtered = reactExports.useMemo(() => providers.filter((p) => {
    const matchCat = active === "all" || p.cat === active;
    const q = query.toLowerCase();
    const matchQ = !q || p.name.toLowerCase().includes(q) || p.specialty.toLowerCase().includes(q) || p.city.toLowerCase().includes(q) || p.province.toLowerCase().includes(q);
    return matchCat && matchQ;
  }), [active, query]);
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-h-screen bg-background", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(SiteHeader, {}),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("main", { id: "main-content", className: "mx-auto max-w-5xl px-5 py-10", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("header", { className: "max-w-2xl", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm font-semibold uppercase tracking-[0.2em] text-accent", children: "Health services" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "mt-2 text-3xl font-bold tracking-tight sm:text-4xl", children: "Find trusted health professionals near you" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-3 text-muted-foreground", children: "Search GPs, specialists, therapists and helplines across every province of South Africa." })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative mt-8", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Search, { className: "absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("input", { value: query, onChange: (e) => setQuery(e.target.value), placeholder: "Search by name, specialty, city or province", "aria-label": "Search health providers", className: "w-full rounded-2xl border border-border bg-card py-3 pl-9 pr-3 text-sm outline-none focus:ring-2 focus:ring-primary/30" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "no-scrollbar mt-4 flex gap-2 overflow-x-auto pb-1", children: categories.map((c) => {
        const Icon = c.icon;
        const on = active === c.id;
        return /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { onClick: () => setActive(c.id), "aria-pressed": on, className: `flex shrink-0 items-center gap-1.5 rounded-full border px-3 py-1.5 text-xs font-medium transition ${on ? "border-primary bg-primary text-primary-foreground" : "border-border bg-card text-foreground hover:bg-muted"}`, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Icon, { className: "h-3.5 w-3.5" }),
          c.label
        ] }, c.id);
      }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("section", { className: "mt-6 rounded-2xl border border-destructive/30 bg-destructive/10 p-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start gap-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(CircleAlert, { className: "mt-0.5 h-5 w-5 shrink-0 text-destructive" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm font-semibold text-foreground", children: "Emergency?" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "mt-0.5 text-xs text-muted-foreground", children: [
            "Call ",
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-semibold text-foreground", children: "10177" }),
            " ",
            "(ambulance) or",
            " ",
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-semibold text-foreground", children: "112" }),
            " from a mobile."
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("a", { href: "tel:10177", className: "rounded-full bg-destructive px-3 py-1.5 text-xs font-semibold text-destructive-foreground", children: "Call" })
      ] }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-6 flex items-center justify-between", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("h2", { className: "text-sm font-semibold", children: [
          filtered.length,
          " ",
          filtered.length === 1 ? "provider" : "providers"
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "flex items-center gap-1 text-xs text-muted-foreground", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(MapPin, { className: "h-3 w-3" }),
          " South Africa"
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("ul", { className: "mt-3 grid gap-3 sm:grid-cols-2", children: [
        filtered.map((p) => /* @__PURE__ */ jsxRuntimeExports.jsxs("li", { className: "rounded-2xl border border-border bg-card p-4 shadow-[var(--shadow-soft)]", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start justify-between gap-3", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "font-semibold", children: p.name }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-muted-foreground", children: p.specialty })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "flex items-center gap-1 rounded-full bg-secondary px-2 py-0.5 text-xs font-semibold text-primary", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Star, { className: "h-3 w-3 fill-current" }),
              " ",
              p.rating
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-3 flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-muted-foreground", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "flex items-center gap-1", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(MapPin, { className: "h-3 w-3" }),
              " ",
              p.city,
              ", ",
              p.province
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "flex items-center gap-1", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Clock, { className: "h-3 w-3" }),
              " ",
              p.nextSlot
            ] })
          ] })
        ] }, p.name)),
        filtered.length === 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("li", { className: "col-span-full rounded-2xl border border-dashed border-border p-8 text-center text-sm text-muted-foreground", children: "No providers match your search. Try another specialty or province." })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-10 rounded-3xl border border-border bg-secondary/40 p-6 text-center", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-lg font-bold", children: "Need an eye test or wheelchair service?" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-1 text-sm text-muted-foreground", children: "Book directly with Wheels & Vision for All." }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { asChild: true, variant: "hero", className: "mt-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Link, { to: "/book", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(CalendarCheck, { className: "h-4 w-4" }),
          " Book an appointment"
        ] }) })
      ] })
    ] })
  ] });
}
export {
  HealthPage as component
};
