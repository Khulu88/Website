import { b as QueryClient } from "../_libs/tanstack__query-core.mjs";
import { Q as QueryClientProvider } from "../_libs/tanstack__react-query.mjs";
import { c as createRouter, a as createRootRouteWithContext, u as useRouter, L as Link, O as Outlet, H as HeadContent, S as Scripts, b as createFileRoute, l as lazyRouteComponent } from "../_libs/tanstack__react-router.mjs";
import { r as reactExports, j as jsxRuntimeExports } from "../_libs/react.mjs";
import { s as supabase } from "./client-Dt-bKJUW.mjs";
import { S as Slot } from "../_libs/radix-ui__react-slot.mjs";
import { c as cva } from "../_libs/class-variance-authority.mjs";
import { c as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { R as Root, T as Thumb } from "../_libs/radix-ui__react-switch.mjs";
import { T as Toaster$1 } from "../_libs/sonner.mjs";
import { X, A as Accessibility, E as Eye, T as Type, C as Contrast, U as Underline, P as Pause, M as MousePointer2, R as RotateCcw } from "../_libs/lucide-react.mjs";
import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval.mjs";
import "../_libs/seroval-plugins.mjs";
import "node:stream/web";
import "node:stream";
import "../_libs/react-dom.mjs";
import "util";
import "crypto";
import "async_hooks";
import "stream";
import "../_libs/isbot.mjs";
import "../_libs/supabase__supabase-js.mjs";
import "../_libs/supabase__postgrest-js.mjs";
import "../_libs/supabase__realtime-js.mjs";
import "../_libs/supabase__phoenix.mjs";
import "../_libs/supabase__storage-js.mjs";
import "../_libs/iceberg-js.mjs";
import "../_libs/supabase__auth-js.mjs";
import "tslib";
import "../_libs/supabase__functions-js.mjs";
import "../_libs/radix-ui__react-compose-refs.mjs";
import "../_libs/radix-ui__primitive.mjs";
import "../_libs/radix-ui__react-context.mjs";
import "../_libs/@radix-ui/react-use-controllable-state+[...].mjs";
import "../_libs/@radix-ui/react-use-layout-effect+[...].mjs";
import "../_libs/radix-ui__react-use-previous.mjs";
import "../_libs/radix-ui__react-use-size.mjs";
import "../_libs/radix-ui__react-primitive.mjs";
const appCss = "/assets/styles-xZkiHtQ_.css";
function reportLovableError(error, context = {}) {
  if (typeof window === "undefined") return;
  window.__lovableEvents?.captureException?.(
    error,
    {
      source: "react_error_boundary",
      route: window.location.pathname,
      ...context
    },
    {
      mechanism: "react_error_boundary",
      handled: false,
      severity: "error"
    }
  );
}
const DEFAULTS = {
  fontScale: 1,
  highContrast: false,
  underlineLinks: false,
  reduceMotion: false,
  readableFont: false,
  bigCursor: false
};
const STORAGE_KEY$1 = "wv-a11y-settings";
const A11yContext = reactExports.createContext(void 0);
function AccessibilityProvider({ children }) {
  const [settings, setSettings] = reactExports.useState(DEFAULTS);
  const [speaking, setSpeaking] = reactExports.useState(false);
  reactExports.useEffect(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY$1);
      if (raw) setSettings({ ...DEFAULTS, ...JSON.parse(raw) });
    } catch {
    }
  }, []);
  reactExports.useEffect(() => {
    const root = document.documentElement;
    root.style.setProperty("--a11y-font-scale", String(settings.fontScale));
    root.classList.toggle("a11y-contrast", settings.highContrast);
    root.classList.toggle("a11y-underline", settings.underlineLinks);
    root.classList.toggle("a11y-reduce-motion", settings.reduceMotion);
    root.classList.toggle("a11y-readable", settings.readableFont);
    root.classList.toggle("a11y-big-cursor", settings.bigCursor);
    try {
      localStorage.setItem(STORAGE_KEY$1, JSON.stringify(settings));
    } catch {
    }
  }, [settings]);
  const update = (key, value) => setSettings((s) => ({ ...s, [key]: value }));
  const reset = () => setSettings(DEFAULTS);
  const speak = (text) => {
    if (typeof window === "undefined" || !("speechSynthesis" in window)) return;
    window.speechSynthesis.cancel();
    const utter = new SpeechSynthesisUtterance(text);
    utter.rate = 0.95;
    utter.onend = () => setSpeaking(false);
    utter.onerror = () => setSpeaking(false);
    setSpeaking(true);
    window.speechSynthesis.speak(utter);
  };
  const stopSpeaking = () => {
    if (typeof window !== "undefined" && "speechSynthesis" in window) {
      window.speechSynthesis.cancel();
    }
    setSpeaking(false);
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsx(
    A11yContext.Provider,
    {
      value: { settings, update, reset, speak, stopSpeaking, speaking },
      children
    }
  );
}
function useA11y() {
  const ctx = reactExports.useContext(A11yContext);
  if (!ctx) throw new Error("useA11y must be used within AccessibilityProvider");
  return ctx;
}
const STORAGE_KEY = "wv-lang";
const en = {
  // Nav
  "nav.about": "About",
  "nav.programmes": "Programmes",
  "nav.impact": "Impact",
  "nav.involved": "Get Involved",
  "nav.contact": "Contact",
  "nav.knowledge": "Knowledge Hub",
  "nav.health": "Health",
  "nav.home": "Home",
  "nav.book": "Book",
  "nav.assistant": "Assistant",
  "nav.signIn": "Sign in",
  "nav.bookNow": "Book now",
  "nav.signOut": "Sign out",
  "nav.account": "My account",
  "nav.admin": "Admin",
  // Hero
  "hero.title": "Mobility & sight, restored for every community.",
  "hero.subtitle": "We provide wheelchairs, mobility aids, eye screenings and prescription glasses to people who would otherwise go without them in communities right across South Africa.",
  "hero.book": "Book an appointment",
  "hero.support": "Support our work",
  // Services
  "services.heading": "How can we help you today?",
  "services.sub": "Book care, learn, or ask our assistant — all in one place.",
  "services.book.title": "Book an appointment",
  "services.book.text": "Find the nearest hospital or optometrist for an eye test or wheelchair service.",
  "services.knowledge.title": "Knowledge Hub",
  "services.knowledge.text": "Did-you-know facts on eye care, mobility, and your rights — read or listen aloud.",
  "services.assistant.title": "Ask the Assistant",
  "services.assistant.text": "Get instant help with bookings and accessibility questions from our AI assistant.",
  "services.open": "Open",
  // About
  "about.kicker": "Who we are",
  "about.heading": "Dignity through movement and clear sight",
  "about.p1": "Wheels & Vision for All was founded on a simple belief: that no one should lose their independence because they cannot afford a wheelchair or a pair of glasses. Registered under the Non-Profit Organisations Act of 1997, we work closely with families, clinics and volunteers in every South African province.",
  "about.p2": "We deliver practical support that changes lives in every province of South Africa, from cities to rural villages, wherever it is needed most.",
  "about.mobility.title": "Mobility",
  "about.mobility.text": "Wheelchairs & aids",
  "about.vision.title": "Vision",
  "about.vision.text": "Screenings & glasses",
  "about.community.title": "Community",
  "about.community.text": "Local partnerships",
  "about.care.title": "Care",
  "about.care.text": "Long-term support",
  // Programmes
  "prog.kicker": "Our programmes",
  "prog.heading": "Two missions, one promise",
  "prog.wheels.title": "Wheels: Mobility for All",
  "prog.wheels.text": "We source, fit and donate wheelchairs, crutches and mobility aids, then follow up to make sure each person stays mobile and supported.",
  "prog.wheels.p1": "Wheelchair donations & repairs",
  "prog.wheels.p2": "Home assessments & fittings",
  "prog.wheels.p3": "Mobility-aid distribution drives",
  "prog.vision.title": "Vision: Sight for All",
  "prog.vision.text": "Free community eye screenings, referrals for treatment and prescription glasses help people read, work and live with confidence.",
  "prog.vision.p1": "Community eye-screening clinics",
  "prog.vision.p2": "Prescription glasses provision",
  "prog.vision.p3": "Referrals for further treatment",
  // Impact
  "impact.heading": "Small acts, lasting change",
  "impact.sub": "Every contribution turns directly into mobility and sight for a neighbour in need.",
  "impact.reached": "People reached",
  "impact.wheelchairs": "Wheelchairs donated",
  "impact.eyes": "Eyes screened",
  "impact.volunteers": "Volunteers",
  // Involved
  "inv.kicker": "Get involved",
  "inv.heading": "Be part of the change",
  "inv.donate.title": "Donate",
  "inv.donate.text": "Fund a wheelchair, an eye screening or a pair of glasses. Every rand goes directly to the people we serve.",
  "inv.volunteer.title": "Volunteer",
  "inv.volunteer.text": "Join our distribution drives and screening clinics across South Africa. Hands and hearts always welcome.",
  "inv.partner.title": "Partner",
  "inv.partner.text": "Clinics, businesses and donors can help us reach further. Together we can build lasting community impact.",
  "inv.cta": "Reach out to help",
  // Contact
  "contact.kicker": "Contact",
  "contact.heading": "Let's talk",
  "contact.p": "Whether you would like to donate, volunteer, request support or simply learn more, we would love to hear from you.",
  "contact.based": "Serving communities across South Africa",
  "contact.outreach": "Community outreach with no fixed walk-in premises",
  "contact.name": "Name",
  "contact.email": "Email",
  "contact.message": "Message",
  "contact.send": "Send message",
  // Footer
  "footer.rights": "All rights reserved."
};
const xh = {
  // Nav
  "nav.about": "Malunga",
  "nav.programmes": "Iinkqubo",
  "nav.impact": "Impembelelo",
  "nav.involved": "Zibandakanye",
  "nav.contact": "Qhagamshelana",
  "nav.knowledge": "Iziko Lolwazi",
  "nav.health": "Impilo",
  "nav.home": "Ikhaya",
  "nav.book": "Bhukha",
  "nav.assistant": "Umncedisi",
  "nav.signIn": "Ngena",
  "nav.bookNow": "Bhukha ngoku",
  "nav.signOut": "Phuma",
  "nav.account": "Iakhawunti yam",
  "nav.admin": "Umlawuli",
  // Hero
  "hero.title": "Ukunyakaza nokubona, kubuyiselwa kuwo wonke uluntu.",
  "hero.subtitle": "Sinikezela ngezitulo zabakhubazekileyo, izixhobo zokunyakaza, ukuhlolwa kwamehlo neeglasi zonyango kubantu abangenakuzifumana kuwo onke amaphondo oMzantsi Afrika.",
  "hero.book": "Bhukha idinga",
  "hero.support": "Xhasa umsebenzi wethu",
  // Services
  "services.heading": "Singakunceda njani namhlanje?",
  "services.sub": "Bhukha unyango, funda, okanye buza umncedisi wethu — kwindawo enye.",
  "services.book.title": "Bhukha idinga",
  "services.book.text": "Fumana esona sibhedlele okanye ugqirha wamehlo okusondeleyo ukuhlolwa kwamehlo okanye inkonzo yesitulo.",
  "services.knowledge.title": "Iziko Lolwazi",
  "services.knowledge.text": "Iinkcukacha ezimangalisayo ngokhathalelo lwamehlo, ukunyakaza, namalungelo akho — funda okanye umamele.",
  "services.assistant.title": "Buza Umncedisi",
  "services.assistant.text": "Fumana uncedo ngokukhawuleza ngokubhukha nemibuzo yokufikeleleka kumncedisi wethu we-AI.",
  "services.open": "Vula",
  // About
  "about.kicker": "Singoobani",
  "about.heading": "Isidima ngokunyakaza nokubona okucacileyo",
  "about.p1": "I-Wheels & Vision for All yasekwa kwinkolelo elula: ukuba akukho mntu kufuneka aphulukane nenkululeko yakhe ngenxa yokuba engakwazi ukuthenga isitulo sabakhubazekileyo okanye iiglasi. Sibhalisiwe phantsi koMthetho weeNkampani ezingenanzuzo ka-1997, sisebenza ngokusondeleyo neentsapho, iikliniki namavolontiya kuwo onke amaphondo oMzantsi Afrika.",
  "about.p2": "Sinikezela ngenkxaso ebonakalayo etshintsha ubomi kuyo yonke indawo eMzantsi Afrika, kusiya kumaphandle nasemizini yasekhaya, naphi na apho kufunekayo.",
  "about.mobility.title": "Ukunyakaza",
  "about.mobility.text": "Izitulo nezixhobo",
  "about.vision.title": "Umbono",
  "about.vision.text": "Ukuhlolwa neeglasi",
  "about.community.title": "Uluntu",
  "about.community.text": "Intsebenziswano yasekuhlaleni",
  "about.care.title": "Ukhathalelo",
  "about.care.text": "Inkxaso yexesha elide",
  // Programmes
  "prog.kicker": "Iinkqubo zethu",
  "prog.heading": "Iinjongo ezimbini, isithembiso esinye",
  "prog.wheels.title": "Amavili: Ukunyakaza kuwo Wonke",
  "prog.wheels.text": "Sifumana, silungelelanise size sinikezele ngezitulo zabakhubazekileyo, iintonga nezixhobo zokunyakaza, size silandelele ukuqinisekisa ukuba umntu ngamnye uyaqhubeka enyakaza exhaswa.",
  "prog.wheels.p1": "Iminikelo nokulungiswa kwezitulo",
  "prog.wheels.p2": "Uvavanyo nokulinganiselwa ekhaya",
  "prog.wheels.p3": "Iiphulo zokusasaza izixhobo zokunyakaza",
  "prog.vision.title": "Umbono: Ukubona kuwo Wonke",
  "prog.vision.text": "Ukuhlolwa kwamehlo kwasimahla kuluntu, ukuthunyelwa konyango neeglasi zonyango kunceda abantu bafunde, basebenze baphile ngokuzithemba.",
  "prog.vision.p1": "Iikliniki zokuhlola amehlo zoluntu",
  "prog.vision.p2": "Ukunikezelwa kweeglasi zonyango",
  "prog.vision.p3": "Ukuthunyelwa kunyango olongezelelweyo",
  // Impact
  "impact.heading": "Izenzo ezincinci, utshintsho oluhlala ixesha elide",
  "impact.sub": "Wonke umnikelo ujika ngokuthe ngqo ube kukunyakaza nokubona kummelwane oswelayo.",
  "impact.reached": "Abantu abafikelelweyo",
  "impact.wheelchairs": "Izitulo ezinikelweyo",
  "impact.eyes": "Amehlo ahloliweyo",
  "impact.volunteers": "Amavolontiya",
  // Involved
  "inv.kicker": "Zibandakanye",
  "inv.heading": "Yiba yinxalenye yotshintsho",
  "inv.donate.title": "Nikela",
  "inv.donate.text": "Xhasa isitulo, ukuhlolwa kwamehlo okanye iiglasi. Yonke irandi iya ngokuthe ngqo kubantu esibakhonzayo.",
  "inv.volunteer.title": "Yiba livolontiya",
  "inv.volunteer.text": "Joyina iiphulo zethu zokusasaza neekliniki zokuhlola kuwo onke amaphondo oMzantsi Afrika. Izandla neentliziyo zamkelekile rhoqo.",
  "inv.partner.title": "Yiba liqabane",
  "inv.partner.text": "Iikliniki, amashishini nabaxhasi banganceda sifikelele kude ngakumbi. Kunye singakha impembelelo ehlalayo eluntwini.",
  "inv.cta": "Qhagamshelana ukunceda",
  // Contact
  "contact.kicker": "Qhagamshelana",
  "contact.heading": "Masithethe",
  "contact.p": "Nokuba ufuna ukunikela, ukuba livolontiya, ukucela uncedo okanye ukufunda nje ngakumbi, singathanda ukuva kuwe.",
  "contact.based": "Sikhonza amalunga aseMzantsi Afrika wonke",
  "contact.outreach": "Ukufikelela eluntwini ngaphandle kwendawo emiselweyo yokungena",
  "contact.name": "Igama",
  "contact.email": "I-imeyile",
  "contact.message": "Umyalezo",
  "contact.send": "Thumela umyalezo",
  // Footer
  "footer.rights": "Onke amalungelo agciniwe."
};
const dicts = { en, xh };
const languages = [
  { code: "en", label: "English", short: "EN" },
  { code: "xh", label: "isiXhosa", short: "XH" }
];
const I18nContext = reactExports.createContext(void 0);
function I18nProvider({ children }) {
  const [lang, setLangState] = reactExports.useState("en");
  reactExports.useEffect(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw === "en" || raw === "xh") setLangState(raw);
    } catch {
    }
  }, []);
  const setLang = (l) => {
    setLangState(l);
    try {
      localStorage.setItem(STORAGE_KEY, l);
    } catch {
    }
    if (typeof document !== "undefined") {
      document.documentElement.lang = l === "xh" ? "xh" : "en";
    }
  };
  const value = reactExports.useMemo(
    () => ({
      lang,
      setLang,
      t: (key) => dicts[lang][key] ?? dicts.en[key] ?? key
    }),
    [lang]
  );
  return /* @__PURE__ */ jsxRuntimeExports.jsx(I18nContext.Provider, { value, children });
}
function useI18n() {
  const ctx = reactExports.useContext(I18nContext);
  if (!ctx) throw new Error("useI18n must be used within I18nProvider");
  return ctx;
}
const AuthContext = reactExports.createContext(void 0);
function AuthProvider({ children }) {
  const [user, setUser] = reactExports.useState(null);
  const [session, setSession] = reactExports.useState(null);
  const [profile, setProfile] = reactExports.useState(null);
  const [roles, setRoles] = reactExports.useState([]);
  const [loading, setLoading] = reactExports.useState(true);
  const loadUserData = async (uid) => {
    const [{ data: prof }, { data: roleRows }] = await Promise.all([
      supabase.from("profiles").select("*").eq("id", uid).maybeSingle(),
      supabase.from("user_roles").select("role").eq("user_id", uid)
    ]);
    setProfile(prof ?? null);
    setRoles((roleRows ?? []).map((r) => r.role));
  };
  reactExports.useEffect(() => {
    const { data: sub } = supabase.auth.onAuthStateChange((_event, sess) => {
      setSession(sess);
      setUser(sess?.user ?? null);
      if (sess?.user) {
        setTimeout(() => loadUserData(sess.user.id), 0);
      } else {
        setProfile(null);
        setRoles([]);
      }
    });
    supabase.auth.getSession().then(({ data }) => {
      setSession(data.session);
      setUser(data.session?.user ?? null);
      if (data.session?.user) {
        loadUserData(data.session.user.id).finally(() => setLoading(false));
      } else {
        setLoading(false);
      }
    });
    return () => sub.subscription.unsubscribe();
  }, []);
  const value = reactExports.useMemo(
    () => ({
      user,
      session,
      profile,
      roles,
      loading,
      isAdmin: roles.includes("admin"),
      isStaff: roles.includes("admin") || roles.includes("staff"),
      signOut: async () => {
        await supabase.auth.signOut();
      },
      refresh: async () => {
        if (user) await loadUserData(user.id);
      }
    }),
    [user, session, profile, roles, loading]
  );
  return /* @__PURE__ */ jsxRuntimeExports.jsx(AuthContext.Provider, { value, children });
}
function useAuth() {
  const ctx = reactExports.useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
}
function cn(...inputs) {
  return twMerge(clsx(inputs));
}
const buttonVariants = cva(
  "inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium cursor-pointer transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 disabled:cursor-not-allowed [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0",
  {
    variants: {
      variant: {
        default: "bg-primary text-primary-foreground shadow hover:bg-primary/90",
        destructive: "bg-destructive text-destructive-foreground shadow-sm hover:bg-destructive/90",
        outline: "border border-input bg-background shadow-sm hover:bg-accent hover:text-accent-foreground",
        secondary: "bg-secondary text-secondary-foreground shadow-sm hover:bg-secondary/80",
        ghost: "hover:bg-accent hover:text-accent-foreground",
        link: "text-primary underline-offset-4 hover:underline",
        hero: "bg-[image:var(--gradient-primary)] text-primary-foreground shadow-[var(--shadow-soft)] hover:opacity-90",
        heroOutline: "border border-primary-foreground/40 bg-primary-foreground/10 text-primary-foreground backdrop-blur-sm hover:bg-primary-foreground/20"
      },
      size: {
        default: "h-9 px-4 py-2",
        sm: "h-8 rounded-md px-3 text-xs",
        lg: "h-10 rounded-md px-8",
        icon: "h-9 w-9"
      }
    },
    defaultVariants: {
      variant: "default",
      size: "default"
    }
  }
);
const Button = reactExports.forwardRef(
  ({ className, variant, size, asChild = false, ...props }, ref) => {
    const Comp = asChild ? Slot : "button";
    return /* @__PURE__ */ jsxRuntimeExports.jsx(Comp, { className: cn(buttonVariants({ variant, size, className })), ref, ...props });
  }
);
Button.displayName = "Button";
const Switch = reactExports.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ jsxRuntimeExports.jsx(
  Root,
  {
    className: cn(
      "peer inline-flex h-5 w-9 shrink-0 cursor-pointer items-center rounded-full border-2 border-transparent shadow-sm transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background disabled:cursor-not-allowed disabled:opacity-50 data-[state=checked]:bg-primary data-[state=unchecked]:bg-input",
      className
    ),
    ...props,
    ref,
    children: /* @__PURE__ */ jsxRuntimeExports.jsx(
      Thumb,
      {
        className: cn(
          "pointer-events-none block h-4 w-4 rounded-full bg-background shadow-lg ring-0 transition-transform data-[state=checked]:translate-x-4 data-[state=unchecked]:translate-x-0"
        )
      }
    )
  }
));
Switch.displayName = Root.displayName;
const fontSteps = [
  { label: "A", value: 1 },
  { label: "A+", value: 1.15 },
  { label: "A++", value: 1.3 },
  { label: "A+++", value: 1.5 }
];
function AccessibilityMenu() {
  const [open, setOpen] = reactExports.useState(false);
  const { settings, update, reset } = useA11y();
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      "button",
      {
        onClick: () => setOpen((v) => !v),
        "aria-label": "Open accessibility settings",
        "aria-expanded": open,
        className: "fixed bottom-5 left-5 z-[60] flex h-14 w-14 items-center justify-center rounded-full bg-[image:var(--gradient-primary)] text-primary-foreground shadow-[var(--shadow-elegant)] outline-none transition-transform hover:scale-105 focus-visible:ring-4 focus-visible:ring-ring",
        children: open ? /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "h-6 w-6" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Accessibility, { className: "h-7 w-7" })
      }
    ),
    open && /* @__PURE__ */ jsxRuntimeExports.jsxs(
      "div",
      {
        role: "dialog",
        "aria-label": "Accessibility settings",
        className: "fixed bottom-24 left-5 z-[60] w-[min(92vw,22rem)] rounded-2xl border border-border bg-card p-5 shadow-[var(--shadow-elegant)]",
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Eye, { className: "h-5 w-5 text-primary" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-lg font-bold", children: "Accessibility" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-1 text-sm text-muted-foreground", children: "Adjust the site to suit your needs." }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-4", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "flex items-center gap-2 text-sm font-medium", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Type, { className: "h-4 w-4" }),
              " Text size"
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-2 grid grid-cols-4 gap-2", children: fontSteps.map((s) => /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                onClick: () => update("fontScale", s.value),
                "aria-pressed": settings.fontScale === s.value,
                className: `rounded-lg border px-2 py-2 text-sm font-semibold transition-colors ${settings.fontScale === s.value ? "border-primary bg-primary text-primary-foreground" : "border-border bg-background hover:bg-muted"}`,
                children: s.label
              },
              s.value
            )) })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-4 space-y-3", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              ToggleRow,
              {
                icon: /* @__PURE__ */ jsxRuntimeExports.jsx(Contrast, { className: "h-4 w-4" }),
                label: "High contrast",
                checked: settings.highContrast,
                onChange: (v) => update("highContrast", v)
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              ToggleRow,
              {
                icon: /* @__PURE__ */ jsxRuntimeExports.jsx(Underline, { className: "h-4 w-4" }),
                label: "Underline links",
                checked: settings.underlineLinks,
                onChange: (v) => update("underlineLinks", v)
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              ToggleRow,
              {
                icon: /* @__PURE__ */ jsxRuntimeExports.jsx(Type, { className: "h-4 w-4" }),
                label: "Readable font",
                checked: settings.readableFont,
                onChange: (v) => update("readableFont", v)
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              ToggleRow,
              {
                icon: /* @__PURE__ */ jsxRuntimeExports.jsx(Pause, { className: "h-4 w-4" }),
                label: "Reduce motion",
                checked: settings.reduceMotion,
                onChange: (v) => update("reduceMotion", v)
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              ToggleRow,
              {
                icon: /* @__PURE__ */ jsxRuntimeExports.jsx(MousePointer2, { className: "h-4 w-4" }),
                label: "Large cursor",
                checked: settings.bigCursor,
                onChange: (v) => update("bigCursor", v)
              }
            )
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            Button,
            {
              variant: "outline",
              className: "mt-5 w-full",
              onClick: reset,
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(RotateCcw, { className: "h-4 w-4" }),
                " Reset"
              ]
            }
          )
        ]
      }
    )
  ] });
}
function ToggleRow({
  icon,
  label,
  checked,
  onChange
}) {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "flex items-center justify-between gap-3 rounded-lg border border-border bg-background px-3 py-2.5", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "flex items-center gap-2 text-sm font-medium", children: [
      icon,
      label
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(Switch, { checked, onCheckedChange: onChange, "aria-label": label })
  ] });
}
const Toaster = ({ ...props }) => {
  return /* @__PURE__ */ jsxRuntimeExports.jsx(
    Toaster$1,
    {
      className: "toaster group",
      toastOptions: {
        classNames: {
          toast: "group toast group-[.toaster]:bg-background group-[.toaster]:text-foreground group-[.toaster]:border-border group-[.toaster]:shadow-lg",
          description: "group-[.toast]:text-muted-foreground",
          actionButton: "group-[.toast]:bg-primary group-[.toast]:text-primary-foreground",
          cancelButton: "group-[.toast]:bg-muted group-[.toast]:text-muted-foreground"
        }
      },
      ...props
    }
  );
};
function NotFoundComponent() {
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex min-h-screen items-center justify-center bg-background px-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "max-w-md text-center", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "text-7xl font-bold text-foreground", children: "404" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "mt-4 text-xl font-semibold text-foreground", children: "Page not found" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-2 text-sm text-muted-foreground", children: "The page you're looking for doesn't exist or has been moved." }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-6", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
      Link,
      {
        to: "/",
        className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
        children: "Go home"
      }
    ) })
  ] }) });
}
function ErrorComponent({ error, reset }) {
  console.error(error);
  const router2 = useRouter();
  reactExports.useEffect(() => {
    reportLovableError(error, { boundary: "tanstack_root_error_component" });
  }, [error]);
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex min-h-screen items-center justify-center bg-background px-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "max-w-md text-center", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "text-xl font-semibold tracking-tight text-foreground", children: "This page didn't load" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-2 text-sm text-muted-foreground", children: "Something went wrong on our end. You can try refreshing or head back home." }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-6 flex flex-wrap justify-center gap-2", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          onClick: () => {
            router2.invalidate();
            reset();
          },
          className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
          children: "Try again"
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "a",
        {
          href: "/",
          className: "inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent",
          children: "Go home"
        }
      )
    ] })
  ] }) });
}
const Route$a = createRootRouteWithContext()({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: "Wheels & Vision for All | Mobility & Eye Care NPO, South Africa" },
      { name: "description", content: "Wheels & Vision for All is a registered South African non-profit (NPO 320-988) restoring mobility and sight to under-served communities across South Africa." },
      { name: "author", content: "Wheels & Vision for All" },
      { property: "og:title", content: "Wheels & Vision for All" },
      { property: "og:description", content: "Restoring mobility and sight to under-served communities across South Africa." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { name: "twitter:site", content: "@WheelsVision" }
    ],
    links: [
      {
        rel: "stylesheet",
        href: appCss
      }
    ]
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
  errorComponent: ErrorComponent
});
function RootShell({ children }) {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("html", { lang: "en", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("head", { children: /* @__PURE__ */ jsxRuntimeExports.jsx(HeadContent, {}) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("body", { children: [
      children,
      /* @__PURE__ */ jsxRuntimeExports.jsx(Scripts, {})
    ] })
  ] });
}
function RootComponent() {
  const { queryClient } = Route$a.useRouteContext();
  return /* @__PURE__ */ jsxRuntimeExports.jsx(QueryClientProvider, { client: queryClient, children: /* @__PURE__ */ jsxRuntimeExports.jsx(AccessibilityProvider, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(I18nProvider, { children: /* @__PURE__ */ jsxRuntimeExports.jsxs(AuthProvider, { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      "a",
      {
        href: "#main-content",
        className: "sr-only rounded-md bg-primary px-4 py-2 text-primary-foreground focus:not-sr-only focus:absolute focus:left-4 focus:top-4 focus:z-[100]",
        children: "Skip to main content"
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsx(Outlet, {}),
    /* @__PURE__ */ jsxRuntimeExports.jsx(AccessibilityMenu, {}),
    /* @__PURE__ */ jsxRuntimeExports.jsx(Toaster, { richColors: true, position: "top-center" })
  ] }) }) }) });
}
const BASE_URL = "";
const Route$9 = createFileRoute("/sitemap.xml")({
  server: {
    handlers: {
      GET: async () => {
        const entries = [
          { path: "/", changefreq: "weekly", priority: "1.0" }
        ];
        const urls = entries.map(
          (e) => [
            `  <url>`,
            `    <loc>${BASE_URL}${e.path}</loc>`,
            e.changefreq ? `    <changefreq>${e.changefreq}</changefreq>` : null,
            e.priority ? `    <priority>${e.priority}</priority>` : null,
            `  </url>`
          ].filter(Boolean).join("\n")
        );
        const xml = [
          `<?xml version="1.0" encoding="UTF-8"?>`,
          `<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">`,
          ...urls,
          `</urlset>`
        ].join("\n");
        return new Response(xml, {
          headers: {
            "Content-Type": "application/xml",
            "Cache-Control": "public, max-age=3600"
          }
        });
      }
    }
  }
});
const $$splitComponentImporter$7 = () => import("./knowledge-CzsIuiKp.mjs");
const Route$8 = createFileRoute("/knowledge")({
  head: () => ({
    meta: [{
      title: "Did You Know? Accessibility Knowledge Hub — Wheels & Vision"
    }, {
      name: "description",
      content: "Accessible health and rights information on eye care, wheelchair use, and disability rights in South Africa. Read or listen aloud."
    }, {
      property: "og:title",
      content: "Did You Know? Accessibility Knowledge Hub"
    }]
  }),
  component: lazyRouteComponent($$splitComponentImporter$7, "component")
});
const $$splitComponentImporter$6 = () => import("./health-CtZfwQvE.mjs");
const Route$7 = createFileRoute("/health")({
  head: () => ({
    meta: [{
      title: "Find health services near you — Wheels & Vision for All"
    }, {
      name: "description",
      content: "Search trusted GPs, paediatricians, gynaecologists, physiotherapists, mental-health and other health professionals across every province of South Africa."
    }, {
      property: "og:title",
      content: "Find health services near you — Wheels & Vision for All"
    }, {
      property: "og:description",
      content: "Search trusted health professionals across every province of South Africa."
    }, {
      property: "og:type",
      content: "website"
    }]
  }),
  component: lazyRouteComponent($$splitComponentImporter$6, "component")
});
const $$splitComponentImporter$5 = () => import("./dashboard-Cb3_G9d3.mjs");
const Route$6 = createFileRoute("/dashboard")({
  head: () => ({
    meta: [{
      title: "My account — Wheels & Vision for All"
    }]
  }),
  component: lazyRouteComponent($$splitComponentImporter$5, "component")
});
const $$splitComponentImporter$4 = () => import("./book-CALpi3zT.mjs");
const Route$5 = createFileRoute("/book")({
  head: () => ({
    meta: [{
      title: "Book an appointment — Wheels & Vision for All"
    }, {
      name: "description",
      content: "Book an eye test or wheelchair service and replacement at the nearest hospital or optometrist anywhere in South Africa."
    }, {
      property: "og:title",
      content: "Book an appointment — Wheels & Vision for All"
    }]
  }),
  component: lazyRouteComponent($$splitComponentImporter$4, "component")
});
const $$splitComponentImporter$3 = () => import("./auth-CRgFi7rt.mjs");
const Route$4 = createFileRoute("/auth")({
  head: () => ({
    meta: [{
      title: "Sign in — Wheels & Vision for All"
    }, {
      name: "description",
      content: "Sign in or create an account to book appointments and manage your care with Wheels & Vision for All."
    }]
  }),
  component: lazyRouteComponent($$splitComponentImporter$3, "component")
});
const $$splitComponentImporter$2 = () => import("./assistant-D-cH-p7_.mjs");
const Route$3 = createFileRoute("/assistant")({
  head: () => ({
    meta: [{
      title: "Ask the Assistant — Wheels & Vision for All"
    }, {
      name: "description",
      content: "Chat with the Wheels & Vision assistant for help booking appointments, eye care, wheelchair support, and accessibility information."
    }, {
      property: "og:title",
      content: "Ask the Assistant — Wheels & Vision for All"
    }]
  }),
  component: lazyRouteComponent($$splitComponentImporter$2, "component")
});
const $$splitComponentImporter$1 = () => import("./admin-Cy3urQ3v.mjs");
const Route$2 = createFileRoute("/admin")({
  head: () => ({
    meta: [{
      title: "Admin — Wheels & Vision for All"
    }]
  }),
  component: lazyRouteComponent($$splitComponentImporter$1, "component")
});
const $$splitComponentImporter = () => import("./index-DnKZcg8U.mjs");
const Route$1 = createFileRoute("/")({
  head: () => ({
    meta: [{
      title: "Wheels & Vision for All | Mobility & Eye Care NPO, South Africa"
    }, {
      name: "description",
      content: "Wheels & Vision for All is a registered South African non-profit (NPO 320-988) restoring mobility and sight to under-served communities across South Africa."
    }, {
      property: "og:title",
      content: "Wheels & Vision for All"
    }, {
      property: "og:description",
      content: "Restoring mobility and sight to under-served communities across South Africa."
    }, {
      property: "og:type",
      content: "website"
    }]
  }),
  component: lazyRouteComponent($$splitComponentImporter, "component")
});
const SYSTEM_PROMPT = `You are the friendly assistant for "Wheels & Vision for All", a national South African non-profit that restores mobility and sight to under-served communities. You help citizens with:
- Booking eye tests and wheelchair service/replacement at nearby hospitals and optometrists (point them to the Book page).
- Accessible health information about eye care, wheelchair maintenance, and disability rights in South Africa.
- General guidance on the organisation's programmes, donating, and volunteering.

Be warm, clear, and concise. Use simple language suitable for screen readers. Use short paragraphs and plain wording. If asked to book, explain they can use the "Book" page to choose a service, find the nearest facility, and pick a date. If a medical emergency is described, advise contacting emergency services immediately. Do not give specific medical diagnoses.`;
const Route = createFileRoute("/api/chat")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const { messages } = await request.json();
        if (!Array.isArray(messages)) {
          return new Response("Messages are required", { status: 400 });
        }
        const apiKey = process.env.LOVABLE_API_KEY;
        if (!apiKey) {
          return new Response("AI is not configured", { status: 500 });
        }
        const trimmed = messages.filter((m) => m && typeof m.content === "string").slice(-12).map((m) => ({ role: m.role, content: m.content.slice(0, 4e3) }));
        const upstream = await fetch(
          "https://ai.gateway.lovable.dev/v1/chat/completions",
          {
            method: "POST",
            headers: {
              Authorization: `Bearer ${apiKey}`,
              "Content-Type": "application/json"
            },
            body: JSON.stringify({
              model: "google/gemini-2.5-flash",
              stream: true,
              messages: [
                { role: "system", content: SYSTEM_PROMPT },
                ...trimmed
              ]
            })
          }
        );
        if (upstream.status === 429) {
          return new Response(
            JSON.stringify({ error: "Too many requests. Please try again shortly." }),
            { status: 429, headers: { "Content-Type": "application/json" } }
          );
        }
        if (upstream.status === 402) {
          return new Response(
            JSON.stringify({
              error: "The assistant is temporarily unavailable. Please try later."
            }),
            { status: 402, headers: { "Content-Type": "application/json" } }
          );
        }
        if (!upstream.ok || !upstream.body) {
          return new Response(
            JSON.stringify({ error: "The assistant could not respond right now." }),
            { status: 502, headers: { "Content-Type": "application/json" } }
          );
        }
        return new Response(upstream.body, {
          status: 200,
          headers: {
            "Content-Type": "text/event-stream",
            "Cache-Control": "no-cache",
            Connection: "keep-alive"
          }
        });
      }
    }
  }
});
const SitemapDotxmlRoute = Route$9.update({
  id: "/sitemap.xml",
  path: "/sitemap.xml",
  getParentRoute: () => Route$a
});
const KnowledgeRoute = Route$8.update({
  id: "/knowledge",
  path: "/knowledge",
  getParentRoute: () => Route$a
});
const HealthRoute = Route$7.update({
  id: "/health",
  path: "/health",
  getParentRoute: () => Route$a
});
const DashboardRoute = Route$6.update({
  id: "/dashboard",
  path: "/dashboard",
  getParentRoute: () => Route$a
});
const BookRoute = Route$5.update({
  id: "/book",
  path: "/book",
  getParentRoute: () => Route$a
});
const AuthRoute = Route$4.update({
  id: "/auth",
  path: "/auth",
  getParentRoute: () => Route$a
});
const AssistantRoute = Route$3.update({
  id: "/assistant",
  path: "/assistant",
  getParentRoute: () => Route$a
});
const AdminRoute = Route$2.update({
  id: "/admin",
  path: "/admin",
  getParentRoute: () => Route$a
});
const IndexRoute = Route$1.update({
  id: "/",
  path: "/",
  getParentRoute: () => Route$a
});
const ApiChatRoute = Route.update({
  id: "/api/chat",
  path: "/api/chat",
  getParentRoute: () => Route$a
});
const rootRouteChildren = {
  IndexRoute,
  AdminRoute,
  AssistantRoute,
  AuthRoute,
  BookRoute,
  DashboardRoute,
  HealthRoute,
  KnowledgeRoute,
  SitemapDotxmlRoute,
  ApiChatRoute
};
const routeTree = Route$a._addFileChildren(rootRouteChildren)._addFileTypes();
const getRouter = () => {
  const queryClient = new QueryClient();
  const router2 = createRouter({
    routeTree,
    context: { queryClient },
    scrollRestoration: true,
    defaultPreloadStaleTime: 0
  });
  return router2;
};
const router = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  getRouter
}, Symbol.toStringTag, { value: "Module" }));
export {
  Button as B,
  useAuth as a,
  useI18n as b,
  cn as c,
  languages as l,
  router as r,
  useA11y as u
};
